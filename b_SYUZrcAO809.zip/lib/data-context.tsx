'use client'

import { createContext, useContext, useState, type ReactNode } from 'react'
import type {
  User,
  Store,
  Product,
  Order,
  Buyer,
  Subscription,
  Upsell,
  OrderStatus,
  ProductType,
  Category,
  Media,
  AuditLog,
} from './types'
import {
  mockUsers,
  mockStores,
  mockProducts,
  mockOrders,
  mockBuyers,
  mockSubscriptions,
  mockUpsells,
  mockProductTypes,
  mockCategories,
  mockMedia,
  mockSystemAuditLogs,
} from './mock-data'
import { calculateBuyerRisk, isDuplicateOrder } from './order-utils'

interface DataContextType {
  // Data
  users: User[]
  stores: Store[]
  products: Product[]
  orders: Order[]
  buyers: Buyer[]
  subscriptions: Subscription[]
  upsells: Upsell[]
  productTypes: ProductType[]
  categories: Category[]
  media: Media[]
  auditLogs: AuditLog[]

  // User operations
  addUser: (user: Omit<User, 'id' | 'createdAt'>) => User
  updateUser: (id: string, data: Partial<User>) => void
  deleteUser: (id: string) => void

  // Store operations
  addStore: (store: Omit<Store, 'id' | 'createdAt'>) => Store
  updateStore: (id: string, data: Partial<Store>) => void
  deleteStore: (id: string) => void

  // Product operations
  addProduct: (product: Omit<Product, 'id' | 'createdAt' | 'averageRating' | 'totalRatings'>) => Product
  updateProduct: (id: string, data: Partial<Product>) => void
  deleteProduct: (id: string) => void

  // Order operations
  addOrder: (order: Omit<Order, 'id' | 'createdAt' | 'updatedAt'>) => { order?: Order; error?: string }
  updateOrder: (id: string, data: Partial<Order>) => void
  updateOrderStatus: (id: string, status: OrderStatus, performedBy?: string) => void
  deleteOrder: (id: string) => void

  // Buyer operations
  addBuyer: (buyer: Omit<Buyer, 'id' | 'createdAt' | 'totalOrders' | 'rejectedOrders' | 'riskScore'>) => Buyer
  updateBuyer: (id: string, data: Partial<Buyer>) => void
  blacklistBuyer: (id: string, blacklisted: boolean) => void
  findBuyerByPhone: (phone: string) => Buyer | undefined

  // Subscription operations
  addSubscription: (subscription: Omit<Subscription, 'id'>) => Subscription
  updateSubscription: (id: string, data: Partial<Subscription>) => void

  // Upsell operations
  addUpsell: (upsell: Omit<Upsell, 'id'>) => Upsell
  removeUpsell: (id: string) => void

  // Product Type operations
  addProductType: (pt: Omit<ProductType, 'id' | 'createdAt'>) => ProductType
  updateProductType: (id: string, data: Partial<ProductType>) => void
  deleteProductType: (id: string) => void

  // Category operations
  addCategory: (cat: Omit<Category, 'id'>) => Category
  updateCategory: (id: string, data: Partial<Category>) => void
  deleteCategory: (id: string) => void

  // Media operations
  addMedia: (m: Omit<Media, 'id' | 'createdAt'>) => Media
  updateMedia: (id: string, data: Partial<Media>) => void
  deleteMedia: (id: string) => void

  // Audit log
  logAction: (log: Omit<AuditLog, 'id' | 'createdAt'>) => void

  // Helpers
  getStoresByUserId: (userId: string) => Store[]
  getProductsByStoreId: (storeId: string) => Product[]
  getOrdersByStoreId: (storeId: string) => Order[]
  getSubscriptionByUserId: (userId: string) => Subscription | undefined
  getUpsellsByUserId: (userId: string) => Upsell[]
  getProductTypesByStoreId: (storeId: string) => ProductType[]
  getCategoriesByProductType: (productTypeId: string) => Category[]
  getMediaByProduct: (productId: string) => Media[]
}

const DataContext = createContext<DataContextType | undefined>(undefined)

function generateId(prefix: string): string {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`
}

export function DataProvider({ children }: { children: ReactNode }) {
  const [users, setUsers] = useState<User[]>(mockUsers)
  const [stores, setStores] = useState<Store[]>(mockStores)
  const [products, setProducts] = useState<Product[]>(mockProducts)
  const [orders, setOrders] = useState<Order[]>(mockOrders)
  const [buyers, setBuyers] = useState<Buyer[]>(mockBuyers)
  const [subscriptions, setSubscriptions] = useState<Subscription[]>(mockSubscriptions)
  const [upsells, setUpsells] = useState<Upsell[]>(mockUpsells)
  const [productTypes, setProductTypes] = useState<ProductType[]>(mockProductTypes)
  const [categories, setCategories] = useState<Category[]>(mockCategories)
  const [media, setMedia] = useState<Media[]>(mockMedia)
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(mockSystemAuditLogs)

  // Audit log helper
  const logAction = (log: Omit<AuditLog, 'id' | 'createdAt'>) => {
    const entry: AuditLog = {
      ...log,
      id: generateId('audit'),
      createdAt: new Date().toISOString(),
    }
    setAuditLogs((prev) => [entry, ...prev])
  }

  // User operations
  const addUser = (userData: Omit<User, 'id' | 'createdAt'>): User => {
    const newUser: User = {
      ...userData,
      id: generateId('user'),
      createdAt: new Date().toISOString(),
    }
    setUsers((prev) => [...prev, newUser])
    logAction({
      userId: 'admin-1',
      entityType: 'user',
      entityId: newUser.id,
      action: 'create',
      newValue: { email: newUser.email, name: newUser.name, role: newUser.role },
    })
    return newUser
  }

  const updateUser = (id: string, data: Partial<User>) => {
    const previous = users.find((u) => u.id === id)
    setUsers((prev) => prev.map((u) => (u.id === id ? { ...u, ...data } : u)))
    if (previous) {
      logAction({
        userId: 'admin-1',
        entityType: 'user',
        entityId: id,
        action: 'update',
        previousValue: previous as unknown as Record<string, unknown>,
        newValue: data as Record<string, unknown>,
      })
    }
  }

  const deleteUser = (id: string) => {
    setUsers((prev) => prev.filter((u) => u.id !== id))
    logAction({ userId: 'admin-1', entityType: 'user', entityId: id, action: 'delete' })
  }

  // Store operations
  const addStore = (storeData: Omit<Store, 'id' | 'createdAt'>): Store => {
    const newStore: Store = { ...storeData, id: generateId('store'), createdAt: new Date().toISOString() }
    setStores((prev) => [...prev, newStore])
    logAction({
      userId: storeData.userId,
      entityType: 'store',
      entityId: newStore.id,
      action: 'create',
      newValue: { name: newStore.name, slug: newStore.slug },
    })
    return newStore
  }

  const updateStore = (id: string, data: Partial<Store>) => {
    setStores((prev) => prev.map((s) => (s.id === id ? { ...s, ...data } : s)))
    const store = stores.find((s) => s.id === id)
    if (store) {
      logAction({
        userId: store.userId,
        entityType: 'store',
        entityId: id,
        action: 'update',
        newValue: data as Record<string, unknown>,
      })
    }
  }

  const deleteStore = (id: string) => {
    const store = stores.find((s) => s.id === id)
    setStores((prev) => prev.filter((s) => s.id !== id))
    if (store) {
      logAction({ userId: store.userId, entityType: 'store', entityId: id, action: 'delete' })
    }
  }

  // Product operations
  const addProduct = (productData: Omit<Product, 'id' | 'createdAt' | 'averageRating' | 'totalRatings'>): Product => {
    const newProduct: Product = {
      ...productData,
      id: generateId('prod'),
      createdAt: new Date().toISOString(),
      averageRating: 0,
      totalRatings: 0,
    }
    setProducts((prev) => [...prev, newProduct])
    const store = stores.find((s) => s.id === productData.storeId)
    logAction({
      userId: store?.userId ?? 'unknown',
      entityType: 'product',
      entityId: newProduct.id,
      action: 'create',
      newValue: { name: newProduct.name, price: newProduct.price },
    })
    return newProduct
  }

  const updateProduct = (id: string, data: Partial<Product>) => {
    setProducts((prev) => prev.map((p) => (p.id === id ? { ...p, ...data } : p)))
    const product = products.find((p) => p.id === id)
    const store = stores.find((s) => s.id === product?.storeId)
    if (store) {
      logAction({
        userId: store.userId,
        entityType: 'product',
        entityId: id,
        action: 'update',
        newValue: data as Record<string, unknown>,
      })
    }
  }

  const deleteProduct = (id: string) => {
    const product = products.find((p) => p.id === id)
    const store = stores.find((s) => s.id === product?.storeId)
    setProducts((prev) => prev.filter((p) => p.id !== id))
    if (store) {
      logAction({ userId: store.userId, entityType: 'product', entityId: id, action: 'delete' })
    }
  }

  // Order operations
  const addOrder = (
    orderData: Omit<Order, 'id' | 'createdAt' | 'updatedAt'>
  ): { order?: Order; error?: string } => {
    // Anti-duplicate check
    if (isDuplicateOrder(orders, orderData.buyerId, orderData.productId)) {
      return { error: 'Duplicate order detected. A recent order exists for this buyer and product.' }
    }

    // Check blacklist
    const buyer = buyers.find((b) => b.id === orderData.buyerId)
    if (buyer?.isBlacklisted) {
      return { error: 'Buyer is blacklisted. Cannot create order.' }
    }

    const now = new Date().toISOString()
    const newOrder: Order = { ...orderData, id: generateId('order'), createdAt: now, updatedAt: now }
    setOrders((prev) => [...prev, newOrder])

    // Update buyer stats
    if (buyer) {
      updateBuyer(buyer.id, { totalOrders: buyer.totalOrders + 1 })
    }

    const store = stores.find((s) => s.id === orderData.storeId)
    if (store) {
      logAction({
        userId: store.userId,
        entityType: 'order',
        entityId: newOrder.id,
        action: 'create',
        newValue: { total: newOrder.totalPrice, buyer: buyer?.phone },
      })
    }

    return { order: newOrder }
  }

  const updateOrder = (id: string, data: Partial<Order>) => {
    setOrders((prev) =>
      prev.map((o) => (o.id === id ? { ...o, ...data, updatedAt: new Date().toISOString() } : o))
    )
  }

  const updateOrderStatus = (id: string, status: OrderStatus, performedBy?: string) => {
    const order = orders.find((o) => o.id === id)
    if (!order) return

    if (order && (status === 'returned' || status === 'problematic')) {
      const buyer = buyers.find((b) => b.id === order.buyerId)
      if (buyer) {
        const newRejected = buyer.rejectedOrders + 1
        const riskScore = calculateBuyerRisk(buyer.totalOrders, newRejected)
        updateBuyer(buyer.id, { rejectedOrders: newRejected, riskScore })
      }
    }
    updateOrder(id, { status })

    const store = stores.find((s) => s.id === order.storeId)
    logAction({
      userId: performedBy ?? store?.userId ?? 'unknown',
      entityType: 'order',
      entityId: id,
      action: 'status_change',
      previousValue: { status: order.status },
      newValue: { status },
    })
  }

  const deleteOrder = (id: string) => {
    setOrders((prev) => prev.filter((o) => o.id !== id))
  }

  // Buyer operations
  const addBuyer = (
    buyerData: Omit<Buyer, 'id' | 'createdAt' | 'totalOrders' | 'rejectedOrders' | 'riskScore'>
  ): Buyer => {
    const newBuyer: Buyer = {
      ...buyerData,
      id: generateId('buyer'),
      createdAt: new Date().toISOString(),
      totalOrders: 0,
      rejectedOrders: 0,
      riskScore: 'low',
    }
    setBuyers((prev) => [...prev, newBuyer])
    return newBuyer
  }

  const updateBuyer = (id: string, data: Partial<Buyer>) => {
    setBuyers((prev) => prev.map((b) => (b.id === id ? { ...b, ...data } : b)))
  }

  const blacklistBuyer = (id: string, blacklisted: boolean) => {
    updateBuyer(id, { isBlacklisted: blacklisted })
  }

  const findBuyerByPhone = (phone: string) => {
    return buyers.find((b) => b.phone === phone)
  }

  // Subscription operations
  const addSubscription = (subData: Omit<Subscription, 'id'>): Subscription => {
    const newSub: Subscription = { ...subData, id: generateId('sub') }
    setSubscriptions((prev) => [...prev, newSub])
    return newSub
  }

  const updateSubscription = (id: string, data: Partial<Subscription>) => {
    const previous = subscriptions.find((s) => s.id === id)
    setSubscriptions((prev) => prev.map((s) => (s.id === id ? { ...s, ...data } : s)))
    if (previous) {
      logAction({
        userId: 'admin-1',
        entityType: 'subscription',
        entityId: id,
        action: 'update',
        previousValue: { plan: previous.plan },
        newValue: data as Record<string, unknown>,
      })
    }
  }

  // Upsell operations
  const addUpsell = (upsellData: Omit<Upsell, 'id'>): Upsell => {
    const newUpsell: Upsell = { ...upsellData, id: generateId('upsell') }
    setUpsells((prev) => [...prev, newUpsell])
    return newUpsell
  }

  const removeUpsell = (id: string) => {
    setUpsells((prev) => prev.filter((u) => u.id !== id))
  }

  // Product Type operations
  const addProductType = (pt: Omit<ProductType, 'id' | 'createdAt'>): ProductType => {
    const newPt: ProductType = { ...pt, id: generateId('ptype'), createdAt: new Date().toISOString() }
    setProductTypes((prev) => [...prev, newPt])
    return newPt
  }

  const updateProductType = (id: string, data: Partial<ProductType>) => {
    setProductTypes((prev) => prev.map((pt) => (pt.id === id ? { ...pt, ...data } : pt)))
  }

  const deleteProductType = (id: string) => {
    setProductTypes((prev) => prev.filter((pt) => pt.id !== id))
  }

  // Category operations
  const addCategory = (cat: Omit<Category, 'id'>): Category => {
    const newCat: Category = { ...cat, id: generateId('cat') }
    setCategories((prev) => [...prev, newCat])
    return newCat
  }

  const updateCategory = (id: string, data: Partial<Category>) => {
    setCategories((prev) => prev.map((c) => (c.id === id ? { ...c, ...data } : c)))
  }

  const deleteCategory = (id: string) => {
    setCategories((prev) => prev.filter((c) => c.id !== id))
  }

  // Media operations
  const addMedia = (m: Omit<Media, 'id' | 'createdAt'>): Media => {
    const newMedia: Media = { ...m, id: generateId('media'), createdAt: new Date().toISOString() }
    setMedia((prev) => [...prev, newMedia])
    return newMedia
  }

  const updateMedia = (id: string, data: Partial<Media>) => {
    setMedia((prev) => prev.map((m) => (m.id === id ? { ...m, ...data } : m)))
  }

  const deleteMedia = (id: string) => {
    setMedia((prev) => prev.filter((m) => m.id !== id))
  }

  // Helpers
  const getStoresByUserId = (userId: string) => stores.filter((s) => s.userId === userId)
  const getProductsByStoreId = (storeId: string) => products.filter((p) => p.storeId === storeId)
  const getOrdersByStoreId = (storeId: string) => orders.filter((o) => o.storeId === storeId)
  const getSubscriptionByUserId = (userId: string) => subscriptions.find((s) => s.userId === userId)
  const getUpsellsByUserId = (userId: string) => upsells.filter((u) => u.userId === userId)
  const getProductTypesByStoreId = (storeId: string) =>
    productTypes.filter((pt) => pt.storeId === storeId)
  const getCategoriesByProductType = (productTypeId: string) =>
    categories.filter((c) => c.productTypeId === productTypeId)
  const getMediaByProduct = (productId: string) => media.filter((m) => m.productId === productId)

  return (
    <DataContext.Provider
      value={{
        users,
        stores,
        products,
        orders,
        buyers,
        subscriptions,
        upsells,
        productTypes,
        categories,
        media,
        auditLogs,
        addUser,
        updateUser,
        deleteUser,
        addStore,
        updateStore,
        deleteStore,
        addProduct,
        updateProduct,
        deleteProduct,
        addOrder,
        updateOrder,
        updateOrderStatus,
        deleteOrder,
        addBuyer,
        updateBuyer,
        blacklistBuyer,
        findBuyerByPhone,
        addSubscription,
        updateSubscription,
        addUpsell,
        removeUpsell,
        addProductType,
        updateProductType,
        deleteProductType,
        addCategory,
        updateCategory,
        deleteCategory,
        addMedia,
        updateMedia,
        deleteMedia,
        logAction,
        getStoresByUserId,
        getProductsByStoreId,
        getOrdersByStoreId,
        getSubscriptionByUserId,
        getUpsellsByUserId,
        getProductTypesByStoreId,
        getCategoriesByProductType,
        getMediaByProduct,
      }}
    >
      {children}
    </DataContext.Provider>
  )
}

export function useData() {
  const context = useContext(DataContext)
  if (!context) throw new Error('useData must be used within DataProvider')
  return context
}
