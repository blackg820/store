/**
 * Telegram Bot Integration
 *
 * Uses Telegram Bot API for notifications.
 * Requires env var: TELEGRAM_BOT_TOKEN
 */

const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN ?? ''
const TELEGRAM_API_URL = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}`

export function isTelegramConfigured(): boolean {
  return Boolean(TELEGRAM_BOT_TOKEN)
}

export interface TelegramMessage {
  chatId: string
  text: string
  parseMode?: 'HTML' | 'MarkdownV2'
  disableNotification?: boolean
}

export async function sendTelegramMessage(
  message: TelegramMessage
): Promise<boolean> {
  if (!isTelegramConfigured()) {
    console.warn('[Telegram] Bot token not configured - skipping message')
    return false
  }

  try {
    const response = await fetch(`${TELEGRAM_API_URL}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: message.chatId,
        text: message.text,
        parse_mode: message.parseMode ?? 'HTML',
        disable_notification: message.disableNotification ?? false,
      }),
    })
    return response.ok
  } catch (error) {
    console.error('[Telegram] Send error:', error)
    return false
  }
}

/**
 * Notify store owner of new order
 */
export async function notifyNewOrder(params: {
  chatId: string
  orderId: string
  storeName: string
  productName: string
  buyerName: string
  buyerPhone: string
  total: number
  language?: 'en' | 'ar'
}) {
  const lang = params.language ?? 'en'
  const text =
    lang === 'ar'
      ? `<b>طلب جديد</b>\n\nالمتجر: ${params.storeName}\nالمنتج: ${params.productName}\nالمشتري: ${params.buyerName}\nالهاتف: ${params.buyerPhone}\nالمجموع: $${params.total.toFixed(2)}\nرقم الطلب: <code>${params.orderId}</code>`
      : `<b>New Order</b>\n\nStore: ${params.storeName}\nProduct: ${params.productName}\nBuyer: ${params.buyerName}\nPhone: ${params.buyerPhone}\nTotal: $${params.total.toFixed(2)}\nOrder ID: <code>${params.orderId}</code>`

  return sendTelegramMessage({ chatId: params.chatId, text })
}

/**
 * Notify store owner of high-risk buyer alert
 */
export async function notifyHighRiskBuyer(params: {
  chatId: string
  buyerName: string
  buyerPhone: string
  rejectedOrders: number
  totalOrders: number
  language?: 'en' | 'ar'
}) {
  const lang = params.language ?? 'en'
  const text =
    lang === 'ar'
      ? `<b>⚠️ تنبيه: مشتري عالي الخطورة</b>\n\nالاسم: ${params.buyerName}\nالهاتف: ${params.buyerPhone}\nالطلبات المرفوضة: ${params.rejectedOrders}/${params.totalOrders}\n\nيرجى المراجعة قبل التأكيد.`
      : `<b>⚠️ High Risk Buyer Alert</b>\n\nName: ${params.buyerName}\nPhone: ${params.buyerPhone}\nRejected: ${params.rejectedOrders}/${params.totalOrders}\n\nReview before confirming.`

  return sendTelegramMessage({ chatId: params.chatId, text })
}

/**
 * Notify order status change
 */
export async function notifyStatusChange(params: {
  chatId: string
  orderId: string
  oldStatus: string
  newStatus: string
  language?: 'en' | 'ar'
}) {
  const lang = params.language ?? 'en'
  const text =
    lang === 'ar'
      ? `<b>تحديث حالة الطلب</b>\n\nرقم الطلب: <code>${params.orderId}</code>\n${params.oldStatus} ← ${params.newStatus}`
      : `<b>Order Status Updated</b>\n\nOrder: <code>${params.orderId}</code>\n${params.oldStatus} → ${params.newStatus}`

  return sendTelegramMessage({ chatId: params.chatId, text })
}

/**
 * Generate a secure linking token for Telegram setup.
 * Store owner clicks the link, it sets their Telegram user/group ID automatically.
 */
export function generateLinkingUrl(token: string, botUsername = 'StorifyBot'): string {
  return `https://t.me/${botUsername}?start=${token}`
}

export function generateGroupLinkingUrl(
  token: string,
  botUsername = 'StorifyBot'
): string {
  return `https://t.me/${botUsername}?startgroup=${token}`
}
