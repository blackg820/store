'use client'

import { createContext, useContext, useState, useEffect, type ReactNode } from 'react'
import type { User, Language, Direction } from './types'
import { mockUsers } from './mock-data'

interface AuthContextType {
  user: User | null
  language: Language
  direction: Direction
  isLoading: boolean
  login: (email: string, password: string) => Promise<boolean>
  logout: () => void
  setLanguage: (lang: Language) => void
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [language, setLanguageState] = useState<Language>('en')
  const [isLoading, setIsLoading] = useState(true)

  const direction: Direction = language === 'ar' ? 'rtl' : 'ltr'

  useEffect(() => {
    // Check for stored session
    const storedUser = localStorage.getItem('storify_user')
    const storedLang = localStorage.getItem('storify_lang') as Language | null
    
    if (storedUser) {
      try {
        setUser(JSON.parse(storedUser))
      } catch {
        localStorage.removeItem('storify_user')
      }
    }
    
    if (storedLang && (storedLang === 'ar' || storedLang === 'en')) {
      setLanguageState(storedLang)
    }
    
    setIsLoading(false)
  }, [])

  useEffect(() => {
    document.documentElement.dir = direction
    document.documentElement.lang = language
  }, [direction, language])

  const login = async (email: string, password: string): Promise<boolean> => {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 500))
    
    // Mock authentication - in production, this would verify password hash
    const foundUser = mockUsers.find(u => u.email === email && u.isActive)
    
    if (foundUser && password === 'demo123') {
      setUser(foundUser)
      localStorage.setItem('storify_user', JSON.stringify(foundUser))
      return true
    }
    
    return false
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem('storify_user')
  }

  const setLanguage = (lang: Language) => {
    setLanguageState(lang)
    localStorage.setItem('storify_lang', lang)
  }

  return (
    <AuthContext.Provider value={{ user, language, direction, isLoading, login, logout, setLanguage }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider')
  }
  return context
}
