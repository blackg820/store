// Core Types for Multi-Store Order Management System

export type Language = 'ar' | 'en'
export type Direction = 'rtl' | 'ltr'

export type UserRole = 'admin' | 'store_owner'
export type UserMode = 'controlled' | 'unlimited'

export type SubscriptionPlan = 'starter' | 'pro' | 'business' | 'enterprise'

export type OrderStatus = 'pending' | 'confirmed' | 'delivered' | 'returned' | 'problematic'

export type BuyerRisk = 'low' | 'medium' | 'high'

export type MediaVisibility = 'public' | 'private' | 'restricted'

export type CustomFieldType = 'text' | 'number' | 'select' | 'multi-select' | 'boolean' | 'date'

export interface User {
  id: string
  email: string
  name: string
  role: UserRole
  mode: UserMode
  createdAt: string
  isActive: boolean
}

// Product Type System - Dynamic Catalog
export interface ProductType {
  id: string
  storeId: string
  name: string
  nameAr: string
  description: string
  customFields: CustomFieldDefinition[]
  createdAt: string
  isActive: boolean
}

export interface CustomFieldDefinition {
  id: string
  name: string
  nameAr: string
  type: CustomFieldType
  required: boolean
  options?: string[] // For select/multi-select
  defaultValue?: string | number | boolean
}

// Category System - Nested Tree
export interface Category {
  id: string
  productTypeId: string
  parentId: string | null
  name: string
  nameAr: string
  slug: string
  sortOrder: number
  isActive: boolean
}

// Media with Privacy
export interface Media {
  id: string
  productId: string
  url: string
  type: 'image' | 'video'
  visibility: MediaVisibility
  blurHash?: string
  size: number
  metadata?: Record<string, string>
  createdAt: string
}

// Audit Log System
export interface AuditLog {
  id: string
  userId: string
  entityType: 'user' | 'store' | 'product' | 'order' | 'buyer' | 'subscription'
  entityId: string
  action: 'create' | 'update' | 'delete' | 'status_change'
  previousValue?: Record<string, unknown>
  newValue?: Record<string, unknown>
  ipAddress?: string
  userAgent?: string
  createdAt: string
}

export interface Subscription {
  id: string
  userId: string
  plan: SubscriptionPlan
  startDate: string
  endDate: string
  isActive: boolean
  monthlyPrice: number
  yearlyPrice: number
}

export interface PlanLimits {
  stores: number
  productsPerStore: number
  storage: number // in GB
  mediaTypes: ('images' | 'videos')[]
  ratings: boolean
  discounts: boolean
  advancedDiscounts: boolean
  telegramGroup: boolean
  riskDetection: boolean
  exports: boolean
  analytics: boolean
  apiAccess: boolean
  auditLogs: boolean
  prioritySupport: boolean
}

export const PLAN_LIMITS: Record<SubscriptionPlan, PlanLimits> = {
  starter: {
    stores: 1,
    productsPerStore: 50,
    storage: 5,
    mediaTypes: ['images'],
    ratings: false,
    discounts: false,
    advancedDiscounts: false,
    telegramGroup: false,
    riskDetection: false,
    exports: false,
    analytics: false,
    apiAccess: false,
    auditLogs: false,
    prioritySupport: false,
  },
  pro: {
    stores: 3,
    productsPerStore: 300,
    storage: 20,
    mediaTypes: ['images', 'videos'],
    ratings: true,
    discounts: true,
    advancedDiscounts: false,
    telegramGroup: true,
    riskDetection: true,
    exports: true,
    analytics: false,
    apiAccess: false,
    auditLogs: false,
    prioritySupport: false,
  },
  business: {
    stores: 10,
    productsPerStore: Infinity,
    storage: 100,
    mediaTypes: ['images', 'videos'],
    ratings: true,
    discounts: true,
    advancedDiscounts: true,
    telegramGroup: true,
    riskDetection: true,
    exports: true,
    analytics: true,
    apiAccess: true,
    auditLogs: true,
    prioritySupport: true,
  },
  enterprise: {
    stores: Infinity,
    productsPerStore: Infinity,
    storage: Infinity,
    mediaTypes: ['images', 'videos'],
    ratings: true,
    discounts: true,
    advancedDiscounts: true,
    telegramGroup: true,
    riskDetection: true,
    exports: true,
    analytics: true,
    apiAccess: true,
    auditLogs: true,
    prioritySupport: true,
  },
}

export const PLAN_PRICES: Record<SubscriptionPlan, { monthly: number; yearly: number }> = {
  starter: { monthly: 10, yearly: 100 },
  pro: { monthly: 25, yearly: 250 },
  business: { monthly: 50, yearly: 500 },
  enterprise: { monthly: 0, yearly: 0 }, // Custom pricing
}

export interface Upsell {
  id: string
  userId: string
  type: 'extra_store' | 'extra_storage' | 'white_label' | 'analytics_pack' | 'fast_deletion' | 'priority_alerts'
  value?: number // For storage increments
  expiresAt: string
}

export interface Store {
  id: string
  userId: string
  name: string
  nameAr: string
  slug: string
  description: string
  descriptionAr: string
  isActive: boolean
  createdAt: string
  telegramUserId?: string
  telegramGroupId?: string
  globalDiscount?: number
  globalDiscountEndDate?: string
}

export interface Product {
  id: string
  storeId: string
  productTypeId?: string
  categoryId?: string
  name: string
  nameAr: string
  description: string
  descriptionAr: string
  price: number
  images: string[]
  videos: string[]
  media?: Media[]
  isActive: boolean
  createdAt: string
  discount?: number
  discountEndDate?: string
  averageRating: number
  totalRatings: number
  customData?: Record<string, unknown> // Dynamic fields based on product type
}

export interface Buyer {
  id: string
  phone: string
  name: string
  governorate: string
  district: string
  landmark: string
  totalOrders: number
  rejectedOrders: number
  riskScore: BuyerRisk
  isBlacklisted: boolean
  createdAt: string
}

export interface Order {
  id: string
  storeId: string
  productId: string
  buyerId: string
  quantity: number
  totalPrice: number
  status: OrderStatus
  notes: string
  createdAt: string
  updatedAt: string
}

export interface OrderAuditLog {
  id: string
  orderId: string
  action: string
  previousValue?: string
  newValue?: string
  performedBy: string
  performedAt: string
}

export interface ProductRating {
  id: string
  productId: string
  buyerId: string
  rating: number
  createdAt: string
}

export interface TelegramLink {
  id: string
  storeId: string
  type: 'user' | 'group'
  token: string
  expiresAt: string
  isUsed: boolean
}

// Translations
export const translations = {
  en: {
    // Navigation
    dashboard: 'Dashboard',
    stores: 'Stores',
    products: 'Products',
    orders: 'Orders',
    buyers: 'Buyers',
    users: 'Users',
    subscriptions: 'Subscriptions',
    settings: 'Settings',
    logout: 'Logout',
    login: 'Login',
    
    // Common
    add: 'Add',
    edit: 'Edit',
    delete: 'Delete',
    save: 'Save',
    cancel: 'Cancel',
    search: 'Search',
    filter: 'Filter',
    export: 'Export',
    actions: 'Actions',
    status: 'Status',
    date: 'Date',
    name: 'Name',
    email: 'Email',
    phone: 'Phone',
    address: 'Address',
    price: 'Price',
    quantity: 'Quantity',
    total: 'Total',
    notes: 'Notes',
    active: 'Active',
    inactive: 'Inactive',
    yes: 'Yes',
    no: 'No',
    
    // Dashboard
    totalOrders: 'Total Orders',
    totalStores: 'Total Stores',
    totalRevenue: 'Total Revenue',
    totalBuyers: 'Total Buyers',
    recentOrders: 'Recent Orders',
    topStores: 'Top Stores',
    
    // Orders
    pending: 'Pending',
    confirmed: 'Confirmed',
    delivered: 'Delivered',
    returned: 'Returned',
    problematic: 'Problematic',
    orderDetails: 'Order Details',
    newOrder: 'New Order',
    editOrder: 'Edit Order',
    
    // Buyers
    lowRisk: 'Low Risk',
    mediumRisk: 'Medium Risk',
    highRisk: 'High Risk',
    blacklisted: 'Blacklisted',
    
    // Plans
    starter: 'Starter',
    pro: 'Pro',
    business: 'Business',
    enterprise: 'Enterprise',
    
    // Auth
    welcomeBack: 'Welcome back',
    signInToContinue: 'Sign in to continue to your dashboard',
    password: 'Password',
    rememberMe: 'Remember me',
    forgotPassword: 'Forgot password?',
    
    // Store
    storeName: 'Store Name',
    storeSlug: 'Store URL Slug',
    storeDescription: 'Description',
    telegramSettings: 'Telegram Settings',
    generateLink: 'Generate Link',
    linkTelegram: 'Link Telegram',
    
    // Product
    productName: 'Product Name',
    productDescription: 'Product Description',
    productPrice: 'Price',
    productImages: 'Images',
    productVideos: 'Videos',
    discount: 'Discount',
    rating: 'Rating',
    
    // Misc
    noData: 'No data available',
    loading: 'Loading...',
    error: 'An error occurred',
    success: 'Success',
    confirm: 'Confirm',
    areYouSure: 'Are you sure?',
  },
  ar: {
    // Navigation
    dashboard: 'لوحة التحكم',
    stores: 'المتاجر',
    products: 'المنتجات',
    orders: 'الطلبات',
    buyers: 'المشترين',
    users: 'المستخدمين',
    subscriptions: 'الاشتراكات',
    settings: 'الإعدادات',
    logout: 'تسجيل الخروج',
    login: 'تسجيل الدخول',
    
    // Common
    add: 'إضافة',
    edit: 'تعديل',
    delete: 'حذف',
    save: 'حفظ',
    cancel: 'إلغاء',
    search: 'بحث',
    filter: 'تصفية',
    export: 'تصدير',
    actions: 'الإجراءات',
    status: 'الحالة',
    date: 'التاريخ',
    name: 'الاسم',
    email: 'البريد الإلكتروني',
    phone: 'الهاتف',
    address: 'العنوان',
    price: 'السعر',
    quantity: 'الكمية',
    total: 'المجموع',
    notes: 'ملاحظات',
    active: 'نشط',
    inactive: 'غير نشط',
    yes: 'نعم',
    no: 'لا',
    
    // Dashboard
    totalOrders: 'إجمالي الطلبات',
    totalStores: 'إجمالي المتاجر',
    totalRevenue: 'إجمالي الإيرادات',
    totalBuyers: 'إجمالي المشترين',
    recentOrders: 'أحدث الطلبات',
    topStores: 'أفضل المتاجر',
    
    // Orders
    pending: 'قيد الانتظار',
    confirmed: 'مؤكد',
    delivered: 'تم التسليم',
    returned: 'مرتجع',
    problematic: 'مشكلة',
    orderDetails: 'تفاصيل الطلب',
    newOrder: 'طلب جديد',
    editOrder: 'تعديل الطلب',
    
    // Buyers
    lowRisk: 'خطر منخفض',
    mediumRisk: 'خطر متوسط',
    highRisk: 'خطر عالي',
    blacklisted: 'محظور',
    
    // Plans
    starter: 'المبتدئ',
    pro: 'المحترف',
    business: 'الأعمال',
    enterprise: 'المؤسسات',
    
    // Auth
    welcomeBack: 'مرحباً بعودتك',
    signInToContinue: 'سجل الدخول للمتابعة إلى لوحة التحكم',
    password: 'كلمة المرور',
    rememberMe: 'تذكرني',
    forgotPassword: 'نسيت كلمة المرور؟',
    
    // Store
    storeName: 'اسم المتجر',
    storeSlug: 'رابط المتجر',
    storeDescription: 'الوصف',
    telegramSettings: 'إعدادات تيليجرام',
    generateLink: 'إنشاء رابط',
    linkTelegram: 'ربط تيليجرام',
    
    // Product
    productName: 'اسم المنتج',
    productDescription: 'وصف المنتج',
    productPrice: 'السعر',
    productImages: 'الصور',
    productVideos: 'الفيديوهات',
    discount: 'خصم',
    rating: 'التقييم',
    
    // Misc
    noData: 'لا توجد بيانات',
    loading: 'جاري التحميل...',
    error: 'حدث خطأ',
    success: 'نجاح',
    confirm: 'تأكيد',
    areYouSure: 'هل أنت متأكد؟',
  },
}

export type TranslationKey = keyof typeof translations.en
