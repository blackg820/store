// JWT Authentication Utilities
// Note: In production, use a proper JWT library like jose

import { User } from './types'

const JWT_SECRET = process.env.JWT_SECRET || 'storify-secret-key-change-in-production'
const ACCESS_TOKEN_EXPIRY = 15 * 60 * 1000 // 15 minutes
const REFRESH_TOKEN_EXPIRY = 7 * 24 * 60 * 60 * 1000 // 7 days

interface TokenPayload {
  userId: string
  email: string
  role: string
  mode: string
  exp: number
  iat: number
  type: 'access' | 'refresh'
}

// Simple base64 encoding (in production use proper JWT library)
function base64Encode(str: string): string {
  if (typeof Buffer !== 'undefined') {
    return Buffer.from(str).toString('base64url')
  }
  return btoa(str).replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '')
}

function base64Decode(str: string): string {
  if (typeof Buffer !== 'undefined') {
    return Buffer.from(str, 'base64url').toString()
  }
  return atob(str.replace(/-/g, '+').replace(/_/g, '/'))
}

// Simple HMAC-like signature (in production use proper crypto)
function createSignature(data: string): string {
  let hash = 0
  const combined = data + JWT_SECRET
  for (let i = 0; i < combined.length; i++) {
    const char = combined.charCodeAt(i)
    hash = ((hash << 5) - hash) + char
    hash = hash & hash
  }
  return base64Encode(hash.toString())
}

export function generateAccessToken(user: User): string {
  const payload: TokenPayload = {
    userId: user.id,
    email: user.email,
    role: user.role,
    mode: user.mode,
    iat: Date.now(),
    exp: Date.now() + ACCESS_TOKEN_EXPIRY,
    type: 'access',
  }
  
  const header = base64Encode(JSON.stringify({ alg: 'HS256', typ: 'JWT' }))
  const body = base64Encode(JSON.stringify(payload))
  const signature = createSignature(`${header}.${body}`)
  
  return `${header}.${body}.${signature}`
}

export function generateRefreshToken(user: User): string {
  const payload: TokenPayload = {
    userId: user.id,
    email: user.email,
    role: user.role,
    mode: user.mode,
    iat: Date.now(),
    exp: Date.now() + REFRESH_TOKEN_EXPIRY,
    type: 'refresh',
  }
  
  const header = base64Encode(JSON.stringify({ alg: 'HS256', typ: 'JWT' }))
  const body = base64Encode(JSON.stringify(payload))
  const signature = createSignature(`${header}.${body}`)
  
  return `${header}.${body}.${signature}`
}

export function verifyToken(token: string): TokenPayload | null {
  try {
    const parts = token.split('.')
    if (parts.length !== 3) return null
    
    const [header, body, signature] = parts
    const expectedSignature = createSignature(`${header}.${body}`)
    
    if (signature !== expectedSignature) return null
    
    const payload: TokenPayload = JSON.parse(base64Decode(body))
    
    if (payload.exp < Date.now()) return null
    
    return payload
  } catch {
    return null
  }
}

export function extractTokenFromHeader(authHeader: string | null): string | null {
  if (!authHeader || !authHeader.startsWith('Bearer ')) return null
  return authHeader.substring(7)
}

// API Response helpers
export interface ApiResponse<T = unknown> {
  success: boolean
  data?: T
  error?: string
  message?: string
  pagination?: {
    page: number
    limit: number
    total: number
    totalPages: number
  }
}

export function successResponse<T>(data: T, message?: string): ApiResponse<T> {
  return { success: true, data, message }
}

export function errorResponse(error: string, statusCode?: number): ApiResponse {
  return { success: false, error }
}

export function paginatedResponse<T>(
  data: T[],
  page: number,
  limit: number,
  total: number
): ApiResponse<T[]> {
  return {
    success: true,
    data,
    pagination: {
      page,
      limit,
      total,
      totalPages: Math.ceil(total / limit),
    },
  }
}
