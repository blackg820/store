import type { Order, Buyer, BuyerRisk } from './types'

/**
 * Anti-duplicate order detection.
 * Blocks orders with same phone + same product within the defined time window.
 */
const DUPLICATE_WINDOW_MS = 24 * 60 * 60 * 1000 // 24 hours

export function isDuplicateOrder(
  orders: Order[],
  buyerId: string,
  productId: string,
  windowMs: number = DUPLICATE_WINDOW_MS
): boolean {
  const now = Date.now()
  return orders.some(
    (order) =>
      order.buyerId === buyerId &&
      order.productId === productId &&
      now - new Date(order.createdAt).getTime() < windowMs &&
      order.status !== 'returned' &&
      order.status !== 'problematic'
  )
}

/**
 * Recalculate buyer risk score based on order history.
 * Low: <20% rejection rate, Medium: 20-50%, High: >50%
 */
export function calculateBuyerRisk(
  totalOrders: number,
  rejectedOrders: number
): BuyerRisk {
  if (totalOrders === 0) return 'low'
  const ratio = rejectedOrders / totalOrders
  if (ratio > 0.5) return 'high'
  if (ratio > 0.2) return 'medium'
  return 'low'
}

/**
 * Validate Egyptian phone number format.
 * Accepts: +20xxxxxxxxxx, 00201xxxxxxxx, 01xxxxxxxxx
 */
export function normalizePhone(phone: string): string {
  const digits = phone.replace(/\D/g, '')
  if (digits.startsWith('0020')) return `+20${digits.slice(4)}`
  if (digits.startsWith('20')) return `+${digits}`
  if (digits.startsWith('01')) return `+20${digits.slice(1)}`
  return `+${digits}`
}

export function validatePhone(phone: string): boolean {
  const normalized = normalizePhone(phone)
  // Egyptian mobile: +20 followed by 10 digits starting with 1
  return /^\+20[0-9]{10}$/.test(normalized)
}

/**
 * Store ranking algorithm based on multiple factors.
 */
export interface StoreRankingMetrics {
  storeId: string
  totalOrders: number
  deliveredOrders: number
  revenue: number
  averageRating: number
  rejectionRate: number
  score: number
}

export function calculateStoreRanking(
  storeId: string,
  orders: Order[],
  products: { averageRating: number; totalRatings: number; storeId: string }[]
): StoreRankingMetrics {
  const storeOrders = orders.filter((o) => o.storeId === storeId)
  const delivered = storeOrders.filter((o) => o.status === 'delivered').length
  const rejected = storeOrders.filter(
    (o) => o.status === 'returned' || o.status === 'problematic'
  ).length
  const revenue = storeOrders
    .filter((o) => o.status === 'delivered')
    .reduce((sum, o) => sum + o.totalPrice, 0)

  const storeProducts = products.filter((p) => p.storeId === storeId)
  const totalRatingSum = storeProducts.reduce(
    (sum, p) => sum + p.averageRating * p.totalRatings,
    0
  )
  const totalRatingCount = storeProducts.reduce(
    (sum, p) => sum + p.totalRatings,
    0
  )
  const averageRating = totalRatingCount > 0 ? totalRatingSum / totalRatingCount : 0

  const rejectionRate = storeOrders.length > 0 ? rejected / storeOrders.length : 0

  // Weighted score: revenue 40%, delivered 30%, rating 20%, low rejection 10%
  const score =
    revenue * 0.4 +
    delivered * 30 +
    averageRating * 200 +
    (1 - rejectionRate) * 100

  return {
    storeId,
    totalOrders: storeOrders.length,
    deliveredOrders: delivered,
    revenue,
    averageRating,
    rejectionRate,
    score: Math.round(score),
  }
}

/**
 * Calculate effective price after discounts (product + store global).
 */
export function calculateEffectivePrice(
  basePrice: number,
  productDiscount?: number,
  productDiscountEnd?: string,
  storeDiscount?: number,
  storeDiscountEnd?: string
): { price: number; discount: number; savings: number } {
  const now = new Date()

  const activeProductDiscount =
    productDiscount &&
    (!productDiscountEnd || new Date(productDiscountEnd) > now)
      ? productDiscount
      : 0

  const activeStoreDiscount =
    storeDiscount && (!storeDiscountEnd || new Date(storeDiscountEnd) > now)
      ? storeDiscount
      : 0

  // Use the larger of the two discounts (not stacked)
  const effectiveDiscount = Math.max(activeProductDiscount, activeStoreDiscount)
  const price = basePrice * (1 - effectiveDiscount / 100)
  const savings = basePrice - price

  return {
    price: Math.round(price * 100) / 100,
    discount: effectiveDiscount,
    savings: Math.round(savings * 100) / 100,
  }
}

/**
 * Validate custom field data against product type schema.
 */
interface CustomFieldDef {
  id: string
  name: string
  type: 'text' | 'number' | 'select' | 'multi-select' | 'boolean' | 'date'
  required: boolean
  options?: string[]
}

export function validateCustomFields(
  data: Record<string, unknown>,
  schema: CustomFieldDef[]
): { valid: boolean; errors: Record<string, string> } {
  const errors: Record<string, string> = {}

  for (const field of schema) {
    const value = data[field.name]

    if (field.required && (value === undefined || value === null || value === '')) {
      errors[field.name] = `${field.name} is required`
      continue
    }

    if (value === undefined || value === null || value === '') continue

    switch (field.type) {
      case 'number':
        if (typeof value !== 'number' && isNaN(Number(value))) {
          errors[field.name] = `${field.name} must be a number`
        }
        break
      case 'boolean':
        if (typeof value !== 'boolean') {
          errors[field.name] = `${field.name} must be a boolean`
        }
        break
      case 'select':
        if (field.options && !field.options.includes(String(value))) {
          errors[field.name] = `${field.name} must be one of: ${field.options.join(', ')}`
        }
        break
      case 'multi-select':
        if (!Array.isArray(value)) {
          errors[field.name] = `${field.name} must be an array`
        } else if (field.options) {
          const invalid = value.filter((v) => !field.options!.includes(String(v)))
          if (invalid.length > 0) {
            errors[field.name] = `Invalid options: ${invalid.join(', ')}`
          }
        }
        break
      case 'date':
        if (isNaN(Date.parse(String(value)))) {
          errors[field.name] = `${field.name} must be a valid date`
        }
        break
    }
  }

  return { valid: Object.keys(errors).length === 0, errors }
}
