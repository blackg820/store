'use client'

import { useState, useEffect, use } from 'react'
import Link from 'next/link'
import { useData } from '@/lib/data-context'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { cn } from '@/lib/utils'
import { Store, Package, Star, Search, Globe, ShoppingCart, ArrowLeft, ArrowRight } from 'lucide-react'

export default function PublicStorePage({ params }: { params: Promise<{ slug: string }> }) {
  const resolvedParams = use(params)
  const { stores, products } = useData()
  const [language, setLanguage] = useState<'en' | 'ar'>('en')
  const [searchQuery, setSearchQuery] = useState('')
  const [mounted, setMounted] = useState(false)
  
  useEffect(() => {
    setMounted(true)
  }, [])

  const store = stores.find(s => s.slug === resolvedParams.slug)
  const storeProducts = store ? products.filter(p => p.storeId === store.id && p.isActive) : []

  const filteredProducts = storeProducts.filter(p => 
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.nameAr.includes(searchQuery)
  )

  const toggleLanguage = () => {
    setLanguage(prev => prev === 'en' ? 'ar' : 'en')
  }

  if (!mounted) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-pulse">Loading...</div>
      </div>
    )
  }

  if (!store) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <Store className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
          <h1 className="text-2xl font-bold mb-2">Store Not Found</h1>
          <p className="text-muted-foreground mb-4">The store you are looking for does not exist.</p>
          <Button asChild>
            <Link href="/">Go Home</Link>
          </Button>
        </div>
      </div>
    )
  }

  if (!store.isActive) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <Store className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
          <h1 className="text-2xl font-bold mb-2">Store Unavailable</h1>
          <p className="text-muted-foreground mb-4">This store is currently not available.</p>
          <Button asChild>
            <Link href="/">Go Home</Link>
          </Button>
        </div>
      </div>
    )
  }

  const direction = language === 'ar' ? 'rtl' : 'ltr'

  return (
    <div className="min-h-screen bg-background" dir={direction}>
      {/* Header */}
      <header className="sticky top-0 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b border-border">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-lg bg-primary flex items-center justify-center">
                <Store className="h-6 w-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="font-bold text-lg">
                  {language === 'ar' ? store.nameAr : store.name}
                </h1>
                {store.globalDiscount && (
                  <Badge variant="secondary" className="bg-success/10 text-success border-success/20 text-xs">
                    {store.globalDiscount}% off all products
                  </Badge>
                )}
              </div>
            </div>
            <Button variant="ghost" size="icon" onClick={toggleLanguage}>
              <Globe className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="bg-primary/5 py-12">
        <div className="container mx-auto px-4 text-center">
          <p className="text-muted-foreground max-w-2xl mx-auto">
            {language === 'ar' ? store.descriptionAr : store.description}
          </p>
          <div className="flex items-center justify-center gap-4 mt-6">
            <div className="flex items-center gap-2">
              <Package className="h-5 w-5 text-primary" />
              <span>{storeProducts.length} Products</span>
            </div>
          </div>
        </div>
      </section>

      {/* Search */}
      <section className="container mx-auto px-4 py-6">
        <div className="relative max-w-md mx-auto">
          <Search className="absolute start-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder={language === 'ar' ? 'البحث عن منتجات...' : 'Search products...'}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="ps-9"
          />
        </div>
      </section>

      {/* Products Grid */}
      <section className="container mx-auto px-4 pb-12">
        {filteredProducts.length === 0 ? (
          <div className="text-center py-12">
            <Package className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">
              {language === 'ar' ? 'لا توجد منتجات' : 'No products found'}
            </p>
          </div>
        ) : (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {filteredProducts.map((product) => {
              const hasDiscount = product.discount || store.globalDiscount
              const discountPercent = product.discount || store.globalDiscount || 0
              const finalPrice = product.price * (1 - discountPercent / 100)

              return (
                <Link
                  key={product.id}
                  href={`/store/${store.slug}/product/${product.id}`}
                  className="group"
                >
                  <Card className="overflow-hidden transition-all hover:shadow-lg hover:border-primary/50">
                    <div className="aspect-square relative bg-muted">
                      {product.images[0] ? (
                        <img
                          src={product.images[0]}
                          alt={language === 'ar' ? product.nameAr : product.name}
                          className="h-full w-full object-cover group-hover:scale-105 transition-transform"
                        />
                      ) : (
                        <div className="h-full w-full flex items-center justify-center">
                          <Package className="h-12 w-12 text-muted-foreground" />
                        </div>
                      )}
                      {hasDiscount && (
                        <Badge className="absolute top-2 start-2 bg-destructive text-destructive-foreground">
                          -{discountPercent}%
                        </Badge>
                      )}
                    </div>
                    <CardContent className="p-4">
                      <h3 className="font-medium truncate group-hover:text-primary transition-colors">
                        {language === 'ar' ? product.nameAr : product.name}
                      </h3>
                      <p className="text-sm text-muted-foreground truncate mt-1">
                        {language === 'ar' ? product.descriptionAr : product.description}
                      </p>
                      <div className="flex items-center justify-between mt-3">
                        <div>
                          <p className="font-bold text-lg">${finalPrice.toFixed(2)}</p>
                          {hasDiscount && (
                            <p className="text-sm text-muted-foreground line-through">
                              ${product.price.toFixed(2)}
                            </p>
                          )}
                        </div>
                        <div className="flex items-center gap-1">
                          <Star className="h-4 w-4 fill-warning text-warning" />
                          <span className="text-sm font-medium">{product.averageRating.toFixed(1)}</span>
                          <span className="text-xs text-muted-foreground">({product.totalRatings})</span>
                        </div>
                      </div>
                      <Button className="w-full mt-4" size="sm">
                        <ShoppingCart className="h-4 w-4 me-2" />
                        {language === 'ar' ? 'اطلب الآن' : 'Order Now'}
                      </Button>
                    </CardContent>
                  </Card>
                </Link>
              )
            })}
          </div>
        )}
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8">
        <div className="container mx-auto px-4 text-center">
          <p className="text-sm text-muted-foreground">
            Powered by <span className="font-semibold">Storify</span>
          </p>
        </div>
      </footer>
    </div>
  )
}
