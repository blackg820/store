'use client'

import { useState, useEffect, use } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useData } from '@/lib/data-context'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { cn } from '@/lib/utils'
import { Store, Package, Star, Globe, ShoppingCart, ArrowLeft, ArrowRight, Check, Minus, Plus } from 'lucide-react'
import { validatePhone, normalizePhone, calculateEffectivePrice } from '@/lib/order-utils'
import { toast } from 'sonner'

export default function ProductPage({ 
  params 
}: { 
  params: Promise<{ slug: string; productId: string }> 
}) {
  const resolvedParams = use(params)
  const router = useRouter()
  const { stores, products, buyers, addBuyer, addOrder } = useData()
  const [language, setLanguage] = useState<'en' | 'ar'>('en')
  const [mounted, setMounted] = useState(false)
  const [quantity, setQuantity] = useState(1)
  const [isOrdering, setIsOrdering] = useState(false)
  const [orderSuccess, setOrderSuccess] = useState(false)
  
  // Order form
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    governorate: '',
    district: '',
    landmark: '',
    notes: '',
  })
  
  useEffect(() => {
    setMounted(true)
  }, [])

  const store = stores.find(s => s.slug === resolvedParams.slug)
  const product = products.find(p => p.id === resolvedParams.productId)

  const toggleLanguage = () => {
    setLanguage(prev => prev === 'en' ? 'ar' : 'en')
  }

  const handleOrder = () => {
    if (!store || !product) return

    // Validate required fields
    if (!formData.name.trim() || !formData.phone.trim() || !formData.governorate.trim()) {
      toast.error(
        language === 'ar' ? 'يرجى ملء جميع الحقول المطلوبة' : 'Please fill all required fields'
      )
      return
    }

    // Validate phone
    if (!validatePhone(formData.phone)) {
      toast.error(
        language === 'ar' ? 'رقم الهاتف غير صالح' : 'Invalid phone number'
      )
      return
    }

    const normalizedPhone = normalizePhone(formData.phone)
    setIsOrdering(true)

    // Find or create buyer
    let buyer = buyers.find((b) => b.phone === normalizedPhone)
    if (!buyer) {
      buyer = addBuyer({
        name: formData.name,
        phone: normalizedPhone,
        governorate: formData.governorate,
        district: formData.district,
        landmark: formData.landmark,
        isBlacklisted: false,
      })
    }

    // Calculate effective price (anti-stacking discount logic)
    const effective = calculateEffectivePrice(
      product.price,
      product.discount,
      product.discountEndDate,
      store.globalDiscount,
      store.globalDiscountEndDate
    )
    const finalPrice = effective.price * quantity

    // Create order (with anti-duplicate and blacklist protection)
    const result = addOrder({
      storeId: store.id,
      productId: product.id,
      buyerId: buyer.id,
      quantity,
      totalPrice: finalPrice,
      status: 'pending',
      notes: formData.notes,
    })

    setIsOrdering(false)

    if (result.error) {
      toast.error(
        language === 'ar'
          ? result.error.includes('Duplicate')
            ? 'لديك طلب مماثل خلال آخر 24 ساعة'
            : result.error.includes('blacklisted')
              ? 'لا يمكن إنشاء الطلب'
              : result.error
          : result.error
      )
      return
    }

    setOrderSuccess(true)
  }

  if (!mounted) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-pulse">Loading...</div>
      </div>
    )
  }

  if (!store || !product) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <Package className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
          <h1 className="text-2xl font-bold mb-2">Product Not Found</h1>
          <p className="text-muted-foreground mb-4">The product you are looking for does not exist.</p>
          <Button asChild>
            <Link href="/">Go Home</Link>
          </Button>
        </div>
      </div>
    )
  }

  const direction = language === 'ar' ? 'rtl' : 'ltr'
  const hasDiscount = product.discount || store.globalDiscount
  const discountPercent = product.discount || store.globalDiscount || 0
  const finalPrice = product.price * (1 - discountPercent / 100)
  const totalPrice = finalPrice * quantity

  if (orderSuccess) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-4" dir={direction}>
        <Card className="max-w-md w-full">
          <CardContent className="p-8 text-center">
            <div className="h-16 w-16 rounded-full bg-success/10 flex items-center justify-center mx-auto mb-4">
              <Check className="h-8 w-8 text-success" />
            </div>
            <h2 className="text-2xl font-bold mb-2">
              {language === 'ar' ? 'تم استلام طلبك!' : 'Order Received!'}
            </h2>
            <p className="text-muted-foreground mb-6">
              {language === 'ar' 
                ? 'سنتواصل معك قريباً لتأكيد الطلب'
                : 'We will contact you shortly to confirm your order'
              }
            </p>
            <div className="space-y-2 text-sm text-start p-4 rounded-lg bg-muted">
              <p><strong>{language === 'ar' ? 'المنتج' : 'Product'}:</strong> {language === 'ar' ? product.nameAr : product.name}</p>
              <p><strong>{language === 'ar' ? 'الكمية' : 'Quantity'}:</strong> {quantity}</p>
              <p><strong>{language === 'ar' ? 'المجموع' : 'Total'}:</strong> ${totalPrice.toFixed(2)}</p>
            </div>
            <div className="flex gap-2 mt-6">
              <Button asChild className="flex-1">
                <Link href={`/store/${store.slug}`}>
                  {language === 'ar' ? 'تصفح المزيد' : 'Browse More'}
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background" dir={direction}>
      {/* Header */}
      <header className="sticky top-0 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b border-border">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="icon" asChild>
                <Link href={`/store/${store.slug}`}>
                  {language === 'ar' ? <ArrowRight className="h-5 w-5" /> : <ArrowLeft className="h-5 w-5" />}
                </Link>
              </Button>
              <div className="flex items-center gap-2">
                <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center">
                  <Store className="h-4 w-4 text-primary-foreground" />
                </div>
                <span className="font-medium">{language === 'ar' ? store.nameAr : store.name}</span>
              </div>
            </div>
            <Button variant="ghost" size="icon" onClick={toggleLanguage}>
              <Globe className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="grid gap-8 lg:grid-cols-2">
          {/* Product Images */}
          <div className="space-y-4">
            <div className="aspect-square rounded-lg bg-muted overflow-hidden relative">
              {product.images[0] ? (
                <img
                  src={product.images[0]}
                  alt={language === 'ar' ? product.nameAr : product.name}
                  className="h-full w-full object-cover"
                />
              ) : (
                <div className="h-full w-full flex items-center justify-center">
                  <Package className="h-24 w-24 text-muted-foreground" />
                </div>
              )}
              {hasDiscount && (
                <Badge className="absolute top-4 start-4 bg-destructive text-destructive-foreground text-lg">
                  -{discountPercent}%
                </Badge>
              )}
            </div>
            {product.images.length > 1 && (
              <div className="flex gap-2 overflow-x-auto pb-2">
                {product.images.map((img, index) => (
                  <div key={index} className="h-20 w-20 rounded-lg bg-muted overflow-hidden shrink-0">
                    <img src={img} alt="" className="h-full w-full object-cover" />
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Product Info & Order Form */}
          <div className="space-y-6">
            <div>
              <h1 className="text-3xl font-bold">
                {language === 'ar' ? product.nameAr : product.name}
              </h1>
              <div className="flex items-center gap-4 mt-2">
                <div className="flex items-center gap-1">
                  <Star className="h-5 w-5 fill-warning text-warning" />
                  <span className="font-medium">{product.averageRating.toFixed(1)}</span>
                  <span className="text-muted-foreground">({product.totalRatings} reviews)</span>
                </div>
              </div>
            </div>

            <div className="flex items-baseline gap-4">
              <p className="text-4xl font-bold">${finalPrice.toFixed(2)}</p>
              {hasDiscount && (
                <p className="text-xl text-muted-foreground line-through">${product.price.toFixed(2)}</p>
              )}
            </div>

            <p className="text-muted-foreground">
              {language === 'ar' ? product.descriptionAr : product.description}
            </p>

            {/* Quantity */}
            <div className="flex items-center gap-4">
              <Label>{language === 'ar' ? 'الكمية' : 'Quantity'}</Label>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                >
                  <Minus className="h-4 w-4" />
                </Button>
                <span className="w-12 text-center font-medium">{quantity}</span>
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => setQuantity(quantity + 1)}
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
              <p className="text-lg font-bold ms-auto">${totalPrice.toFixed(2)}</p>
            </div>

            {/* Order Form */}
            {!isOrdering ? (
              <Button size="lg" className="w-full" onClick={() => setIsOrdering(true)}>
                <ShoppingCart className="h-5 w-5 me-2" />
                {language === 'ar' ? 'اطلب الآن' : 'Order Now'}
              </Button>
            ) : (
              <Card>
                <CardHeader>
                  <CardTitle>{language === 'ar' ? 'معلومات التوصيل' : 'Delivery Information'}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="name">{language === 'ar' ? 'الاسم' : 'Name'} *</Label>
                      <Input
                        id="name"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone">{language === 'ar' ? 'رقم الهاتف' : 'Phone'} *</Label>
                      <Input
                        id="phone"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        placeholder="+20..."
                        dir="ltr"
                        required
                      />
                    </div>
                  </div>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="governorate">{language === 'ar' ? 'المحافظة' : 'Governorate'} *</Label>
                      <Input
                        id="governorate"
                        value={formData.governorate}
                        onChange={(e) => setFormData({ ...formData, governorate: e.target.value })}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="district">{language === 'ar' ? 'المنطقة' : 'District'} *</Label>
                      <Input
                        id="district"
                        value={formData.district}
                        onChange={(e) => setFormData({ ...formData, district: e.target.value })}
                        required
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="landmark">{language === 'ar' ? 'أقرب معلم' : 'Nearest Landmark'}</Label>
                    <Input
                      id="landmark"
                      value={formData.landmark}
                      onChange={(e) => setFormData({ ...formData, landmark: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="notes">{language === 'ar' ? 'ملاحظات' : 'Notes'}</Label>
                    <Textarea
                      id="notes"
                      value={formData.notes}
                      onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                      rows={2}
                    />
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" onClick={() => setIsOrdering(false)}>
                      {language === 'ar' ? 'إلغاء' : 'Cancel'}
                    </Button>
                    <Button 
                      className="flex-1"
                      onClick={handleOrder}
                      disabled={!formData.name || !formData.phone || !formData.governorate || !formData.district}
                    >
                      {language === 'ar' ? 'تأكيد الطلب' : 'Confirm Order'} - ${totalPrice.toFixed(2)}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-border py-8 mt-12">
        <div className="container mx-auto px-4 text-center">
          <p className="text-sm text-muted-foreground">
            Powered by <span className="font-semibold">Storify</span>
          </p>
        </div>
      </footer>
    </div>
  )
}
