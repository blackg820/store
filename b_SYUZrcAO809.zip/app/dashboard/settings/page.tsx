'use client'

import { useState } from 'react'
import { useAuth } from '@/lib/auth-context'
import { useTranslations } from '@/hooks/use-translations'
import { useData } from '@/lib/data-context'
import { DashboardHeader } from '@/components/dashboard/header'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Label } from '@/components/ui/label'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Switch } from '@/components/ui/switch'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { cn } from '@/lib/utils'
import { PLAN_LIMITS, type SubscriptionPlan } from '@/lib/types'
import { User, Bell, Globe, CreditCard, Shield, Send, Copy, ExternalLink, Check, Store } from 'lucide-react'

export default function SettingsPage() {
  const { user, language, setLanguage } = useAuth()
  const { t } = useTranslations()
  const { getSubscriptionByUserId, getStoresByUserId, stores, updateStore } = useData()
  
  const isAdmin = user?.role === 'admin'
  const subscription = user ? getSubscriptionByUserId(user.id) : undefined
  const userStores = user ? getStoresByUserId(user.id) : []
  const planLimits = subscription ? PLAN_LIMITS[subscription.plan] : null

  const [selectedStore, setSelectedStore] = useState(userStores[0]?.id || '')
  const [telegramUserId, setTelegramUserId] = useState('')
  const [telegramGroupId, setTelegramGroupId] = useState('')
  const [copied, setCopied] = useState(false)

  const selectedStoreData = stores.find(s => s.id === selectedStore)

  const generateTelegramLink = (type: 'user' | 'group') => {
    const token = Math.random().toString(36).substring(2, 15)
    const link = `${window.location.origin}/api/telegram/link?token=${token}&store=${selectedStore}&type=${type}`
    navigator.clipboard.writeText(link)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const saveTelegramSettings = () => {
    if (selectedStore) {
      updateStore(selectedStore, {
        telegramUserId: telegramUserId || undefined,
        telegramGroupId: telegramGroupId || undefined,
      })
    }
  }

  return (
    <div className="min-h-screen">
      <DashboardHeader title={t('settings')} />
      
      <div className="p-4 md:p-6 space-y-6">
        <Tabs defaultValue="profile" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-4 lg:w-auto lg:inline-grid">
            <TabsTrigger value="profile">
              <User className="h-4 w-4 me-2" />
              Profile
            </TabsTrigger>
            <TabsTrigger value="telegram">
              <Send className="h-4 w-4 me-2" />
              Telegram
            </TabsTrigger>
            {!isAdmin && (
              <TabsTrigger value="subscription">
                <CreditCard className="h-4 w-4 me-2" />
                Subscription
              </TabsTrigger>
            )}
            <TabsTrigger value="preferences">
              <Globe className="h-4 w-4 me-2" />
              Preferences
            </TabsTrigger>
          </TabsList>

          {/* Profile Tab */}
          <TabsContent value="profile" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Profile Information</CardTitle>
                <CardDescription>Update your account details</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="name">{t('name')}</Label>
                    <Input id="name" defaultValue={user?.name} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">{t('email')}</Label>
                    <Input id="email" type="email" defaultValue={user?.email} disabled />
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant={user?.role === 'admin' ? 'default' : 'secondary'}>
                    {user?.role === 'admin' ? 'Administrator' : 'Store Owner'}
                  </Badge>
                  <Badge variant="outline" className="bg-success/10 text-success border-success/20">
                    {t('active')}
                  </Badge>
                </div>
                <Button>{t('save')}</Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Change Password</CardTitle>
                <CardDescription>Update your password to keep your account secure</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="currentPassword">Current Password</Label>
                    <Input id="currentPassword" type="password" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="newPassword">New Password</Label>
                    <Input id="newPassword" type="password" />
                  </div>
                </div>
                <Button variant="secondary">Change Password</Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Telegram Tab */}
          <TabsContent value="telegram" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>{t('telegramSettings')}</CardTitle>
                <CardDescription>
                  Configure Telegram notifications for your stores
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {userStores.length === 0 && !isAdmin ? (
                  <p className="text-muted-foreground">You dont have any stores yet. Create a store first.</p>
                ) : (
                  <>
                    {!isAdmin && (
                      <div className="space-y-2">
                        <Label>Select Store</Label>
                        <select
                          value={selectedStore}
                          onChange={(e) => setSelectedStore(e.target.value)}
                          className="w-full p-2 rounded-lg border border-input bg-background"
                        >
                          {userStores.map(store => (
                            <option key={store.id} value={store.id}>
                              {language === 'ar' ? store.nameAr : store.name}
                            </option>
                          ))}
                        </select>
                      </div>
                    )}

                    <div className="grid gap-4 sm:grid-cols-2">
                      <div className="space-y-2">
                        <Label htmlFor="telegramUserId">Telegram User ID</Label>
                        <Input
                          id="telegramUserId"
                          value={telegramUserId || selectedStoreData?.telegramUserId || ''}
                          onChange={(e) => setTelegramUserId(e.target.value)}
                          placeholder="123456789"
                        />
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => generateTelegramLink('user')}
                          className="w-full"
                        >
                          {copied ? <Check className="h-4 w-4 me-2" /> : <Copy className="h-4 w-4 me-2" />}
                          {t('generateLink')} (User)
                        </Button>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="telegramGroupId">Telegram Group ID</Label>
                        <Input
                          id="telegramGroupId"
                          value={telegramGroupId || selectedStoreData?.telegramGroupId || ''}
                          onChange={(e) => setTelegramGroupId(e.target.value)}
                          placeholder="-1001234567890"
                          disabled={!planLimits?.telegramGroup && !isAdmin}
                        />
                        {!planLimits?.telegramGroup && !isAdmin && (
                          <p className="text-xs text-muted-foreground">
                            Upgrade to Pro or higher to use group notifications
                          </p>
                        )}
                        {(planLimits?.telegramGroup || isAdmin) && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => generateTelegramLink('group')}
                            className="w-full"
                          >
                            {copied ? <Check className="h-4 w-4 me-2" /> : <Copy className="h-4 w-4 me-2" />}
                            {t('generateLink')} (Group)
                          </Button>
                        )}
                      </div>
                    </div>

                    <div className="p-4 rounded-lg bg-muted space-y-2">
                      <p className="text-sm font-medium">Notification Events:</p>
                      <div className="grid gap-2 sm:grid-cols-2">
                        <div className="flex items-center gap-2">
                          <Switch defaultChecked />
                          <Label className="text-sm">New Orders</Label>
                        </div>
                        <div className="flex items-center gap-2">
                          <Switch defaultChecked />
                          <Label className="text-sm">Order Confirmations</Label>
                        </div>
                        <div className="flex items-center gap-2">
                          <Switch defaultChecked />
                          <Label className="text-sm">Status Changes</Label>
                        </div>
                        <div className="flex items-center gap-2">
                          <Switch defaultChecked />
                          <Label className="text-sm">High-Risk Buyers</Label>
                        </div>
                      </div>
                    </div>

                    <Button onClick={saveTelegramSettings}>{t('save')}</Button>
                  </>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Subscription Tab */}
          {!isAdmin && (
            <TabsContent value="subscription" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Current Subscription</CardTitle>
                  <CardDescription>Manage your subscription plan and add-ons</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {subscription ? (
                    <>
                      <div className="flex items-center justify-between p-4 rounded-lg border border-border">
                        <div>
                          <Badge className="capitalize mb-2">{subscription.plan} Plan</Badge>
                          <p className="font-bold text-2xl">${subscription.monthlyPrice}/month</p>
                          <p className="text-sm text-muted-foreground">
                            Renews on {new Date(subscription.endDate).toLocaleDateString()}
                          </p>
                        </div>
                        <Badge variant={subscription.isActive ? 'default' : 'destructive'}>
                          {subscription.isActive ? 'Active' : 'Expired'}
                        </Badge>
                      </div>

                      <div className="space-y-4">
                        <h4 className="font-medium">Plan Limits</h4>
                        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                          <div className="p-4 rounded-lg bg-muted">
                            <Store className="h-5 w-5 text-primary mb-2" />
                            <p className="text-sm text-muted-foreground">Stores</p>
                            <p className="font-bold">
                              {userStores.length} / {planLimits?.stores === Infinity ? 'Unlimited' : planLimits?.stores}
                            </p>
                          </div>
                          <div className="p-4 rounded-lg bg-muted">
                            <Shield className="h-5 w-5 text-primary mb-2" />
                            <p className="text-sm text-muted-foreground">Products/Store</p>
                            <p className="font-bold">
                              {planLimits?.productsPerStore === Infinity ? 'Unlimited' : planLimits?.productsPerStore}
                            </p>
                          </div>
                          <div className="p-4 rounded-lg bg-muted">
                            <Globe className="h-5 w-5 text-primary mb-2" />
                            <p className="text-sm text-muted-foreground">Storage</p>
                            <p className="font-bold">
                              {planLimits?.storage === Infinity ? 'Unlimited' : `${planLimits?.storage}GB`}
                            </p>
                          </div>
                          <div className="p-4 rounded-lg bg-muted">
                            <Bell className="h-5 w-5 text-primary mb-2" />
                            <p className="text-sm text-muted-foreground">Telegram</p>
                            <p className="font-bold">
                              {planLimits?.telegramGroup ? 'User + Groups' : 'User Only'}
                            </p>
                          </div>
                        </div>
                      </div>

                      <div className="space-y-4">
                        <h4 className="font-medium">Features</h4>
                        <div className="flex flex-wrap gap-2">
                          {planLimits?.ratings && <Badge variant="secondary">Product Ratings</Badge>}
                          {planLimits?.discounts && <Badge variant="secondary">Discounts</Badge>}
                          {planLimits?.advancedDiscounts && <Badge variant="secondary">Advanced Discounts</Badge>}
                          {planLimits?.riskDetection && <Badge variant="secondary">Risk Detection</Badge>}
                          {planLimits?.exports && <Badge variant="secondary">CSV/Excel Export</Badge>}
                          {planLimits?.analytics && <Badge variant="secondary">Analytics</Badge>}
                          {planLimits?.apiAccess && <Badge variant="secondary">API Access</Badge>}
                          {planLimits?.auditLogs && <Badge variant="secondary">Audit Logs</Badge>}
                          {planLimits?.prioritySupport && <Badge variant="secondary">Priority Support</Badge>}
                        </div>
                      </div>
                    </>
                  ) : (
                    <p className="text-muted-foreground">No active subscription. Contact admin to subscribe.</p>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          )}

          {/* Preferences Tab */}
          <TabsContent value="preferences" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Language & Display</CardTitle>
                <CardDescription>Customize your experience</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between p-4 rounded-lg border border-border">
                  <div>
                    <p className="font-medium">Language</p>
                    <p className="text-sm text-muted-foreground">Choose your preferred language</p>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant={language === 'en' ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setLanguage('en')}
                    >
                      English
                    </Button>
                    <Button
                      variant={language === 'ar' ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setLanguage('ar')}
                    >
                      العربية
                    </Button>
                  </div>
                </div>

                <div className="flex items-center justify-between p-4 rounded-lg border border-border">
                  <div>
                    <p className="font-medium">Email Notifications</p>
                    <p className="text-sm text-muted-foreground">Receive email updates about your stores</p>
                  </div>
                  <Switch defaultChecked />
                </div>

                <div className="flex items-center justify-between p-4 rounded-lg border border-border">
                  <div>
                    <p className="font-medium">Order Alerts</p>
                    <p className="text-sm text-muted-foreground">Get notified for high-risk orders</p>
                  </div>
                  <Switch defaultChecked />
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
