'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/lib/auth-context'
import { useTranslations } from '@/hooks/use-translations'
import { useData } from '@/lib/data-context'
import { DashboardHeader } from '@/components/dashboard/header'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import { PLAN_LIMITS, PLAN_PRICES, type SubscriptionPlan } from '@/lib/types'
import { Check, CreditCard, Users, Store, Package, Database, Bell, BarChart3 } from 'lucide-react'

const planColors: Record<SubscriptionPlan, string> = {
  starter: 'border-muted',
  pro: 'border-primary',
  business: 'border-accent',
  enterprise: 'border-warning',
}

export default function SubscriptionsPage() {
  const router = useRouter()
  const { user } = useAuth()
  const { t } = useTranslations()
  const { subscriptions, users } = useData()
  
  // Admin only page
  useEffect(() => {
    if (user && user.role !== 'admin') {
      router.push('/dashboard')
    }
  }, [user, router])

  if (user?.role !== 'admin') {
    return null
  }

  // Calculate stats
  const activeSubscriptions = subscriptions.filter(s => s.isActive)
  const planCounts = {
    starter: activeSubscriptions.filter(s => s.plan === 'starter').length,
    pro: activeSubscriptions.filter(s => s.plan === 'pro').length,
    business: activeSubscriptions.filter(s => s.plan === 'business').length,
    enterprise: activeSubscriptions.filter(s => s.plan === 'enterprise').length,
  }

  const totalMRR = activeSubscriptions.reduce((sum, s) => sum + s.monthlyPrice, 0)

  const plans: { plan: SubscriptionPlan; name: string; price: string; features: string[] }[] = [
    {
      plan: 'starter',
      name: 'Starter',
      price: '$10/mo',
      features: [
        '1 Store',
        '50 Products per store',
        '5GB Storage',
        'Images only',
        'Private Telegram chat',
      ],
    },
    {
      plan: 'pro',
      name: 'Pro',
      price: '$25/mo',
      features: [
        '3 Stores',
        '300 Products per store',
        '20GB Storage',
        'Images + Videos',
        'Telegram groups',
        'Product ratings',
        'Discounts',
        'Buyer risk detection',
        'CSV/Excel export',
      ],
    },
    {
      plan: 'business',
      name: 'Business',
      price: '$50/mo',
      features: [
        '10 Stores',
        'Unlimited Products',
        '100GB Storage',
        'Advanced discounts',
        'Advanced analytics',
        'API access',
        'Full audit logs',
        'Priority support',
      ],
    },
    {
      plan: 'enterprise',
      name: 'Enterprise',
      price: 'Custom',
      features: [
        'Unlimited everything',
        'Full customization',
        'Dedicated server option',
        'Custom integrations',
        '24/7 support',
      ],
    },
  ]

  return (
    <div className="min-h-screen">
      <DashboardHeader title={t('subscriptions')} />
      
      <div className="p-4 md:p-6 space-y-6">
        {/* Revenue Stats */}
        <div className="grid gap-4 sm:grid-cols-5">
          <Card className="sm:col-span-2">
            <CardContent className="p-4 flex items-center gap-4">
              <div className="p-3 rounded-lg bg-success/10">
                <CreditCard className="h-5 w-5 text-success" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Monthly Recurring Revenue</p>
                <p className="text-2xl font-bold">${totalMRR}</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex items-center gap-4">
              <div className="p-3 rounded-lg bg-primary/10">
                <Users className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Active Subscriptions</p>
                <p className="text-2xl font-bold">{activeSubscriptions.length}</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-sm text-muted-foreground mb-1">Plan Distribution</p>
              <div className="flex gap-2 flex-wrap">
                <Badge variant="secondary">{planCounts.starter} Starter</Badge>
                <Badge className="bg-primary/10 text-primary border-primary/20">{planCounts.pro} Pro</Badge>
                <Badge className="bg-accent/10 text-accent border-accent/20">{planCounts.business} Business</Badge>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Plans Grid */}
        <div>
          <h2 className="text-lg font-semibold mb-4">Available Plans</h2>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {plans.map((planInfo) => (
              <Card key={planInfo.plan} className={cn('relative', planColors[planInfo.plan], planInfo.plan === 'pro' && 'border-2')}>
                {planInfo.plan === 'pro' && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                    <Badge className="bg-primary text-primary-foreground">Popular</Badge>
                  </div>
                )}
                <CardHeader>
                  <CardTitle>{planInfo.name}</CardTitle>
                  <CardDescription>
                    <span className="text-2xl font-bold text-foreground">{planInfo.price}</span>
                    {planInfo.plan !== 'enterprise' && (
                      <span className="text-muted-foreground"> or ${PLAN_PRICES[planInfo.plan].yearly}/yr</span>
                    )}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {planInfo.features.map((feature, index) => (
                      <li key={index} className="flex items-start gap-2 text-sm">
                        <Check className="h-4 w-4 text-success shrink-0 mt-0.5" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <div className="mt-4 pt-4 border-t border-border">
                    <p className="text-sm text-muted-foreground">
                      {planCounts[planInfo.plan]} active {planCounts[planInfo.plan] === 1 ? 'subscriber' : 'subscribers'}
                    </p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Recent Subscriptions */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Subscriptions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {subscriptions.slice(0, 5).map((sub) => {
                const subUser = users.find(u => u.id === sub.userId)
                return (
                  <div key={sub.id} className="flex items-center justify-between p-4 rounded-lg border border-border">
                    <div className="flex items-center gap-4">
                      <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                        {subUser?.name?.charAt(0) || 'U'}
                      </div>
                      <div>
                        <p className="font-medium">{subUser?.name}</p>
                        <p className="text-sm text-muted-foreground">{subUser?.email}</p>
                      </div>
                    </div>
                    <div className="text-end">
                      <Badge variant="outline" className={cn('capitalize', planColors[sub.plan])}>
                        {sub.plan}
                      </Badge>
                      <p className="text-xs text-muted-foreground mt-1">
                        Expires: {new Date(sub.endDate).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                )
              })}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
