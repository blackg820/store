import { NextRequest, NextResponse } from 'next/server'
import { mockSubscriptions, mockMedia, mockUsers } from '@/lib/mock-data'

// This endpoint should be called by a cron service (e.g., Vercel Cron)
// Configure in vercel.json with proper authorization

const CRON_SECRET = process.env.CRON_SECRET || 'cron-secret-change-in-production'

export async function POST(request: NextRequest) {
  try {
    // Verify cron secret
    const authHeader = request.headers.get('Authorization')
    if (authHeader !== `Bearer ${CRON_SECRET}`) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const results = {
      expiredSubscriptions: 0,
      suspendedUsers: 0,
      mediaMarkedForDeletion: 0,
      mediaDeleted: 0,
      cleanedSessions: 0,
      timestamp: new Date().toISOString(),
    }

    const now = new Date()
    const gracePeriodDays = 7

    // 1. Check and expire subscriptions
    for (const subscription of mockSubscriptions) {
      const endDate = new Date(subscription.endDate)
      
      if (subscription.isActive && endDate < now) {
        // Mark as inactive
        subscription.isActive = false
        results.expiredSubscriptions++

        // Find user and check mode
        const user = mockUsers.find(u => u.id === subscription.userId)
        if (user && user.mode === 'controlled') {
          // Suspend user after subscription expires
          user.isActive = false
          results.suspendedUsers++
        }
      }
    }

    // 2. Mark media for deletion after grace period
    for (const subscription of mockSubscriptions) {
      if (!subscription.isActive) {
        const endDate = new Date(subscription.endDate)
        const gracePeriodEnd = new Date(endDate.getTime() + gracePeriodDays * 24 * 60 * 60 * 1000)
        
        if (now > gracePeriodEnd) {
          // Find all media belonging to this user's stores
          // In production, this would mark media for deletion in DB
          results.mediaMarkedForDeletion++
        }
      }
    }

    // 3. Clean up expired sessions (simulated)
    // In production, delete expired refresh tokens from user_sessions table
    results.cleanedSessions = Math.floor(Math.random() * 10)

    // 4. Clean up expired rate limits (simulated)
    // In production, delete old rate limit entries

    // 5. Clean up expired Telegram link tokens
    // In production, delete used or expired telegram_links

    return NextResponse.json({
      success: true,
      message: 'Cleanup completed',
      results,
    })
  } catch (error) {
    console.error('[Cron] Cleanup error:', error)
    return NextResponse.json(
      { success: false, error: 'Cleanup failed' },
      { status: 500 }
    )
  }
}

// GET endpoint for health check
export async function GET(request: NextRequest) {
  return NextResponse.json({
    status: 'ok',
    service: 'cleanup-cron',
    timestamp: new Date().toISOString(),
  })
}
