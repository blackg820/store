import { NextResponse, type NextRequest } from 'next/server'
import { checkRateLimit, getClientIdentifier, RATE_LIMITS } from '@/lib/rate-limit'
import { normalizePhone, validatePhone } from '@/lib/order-utils'

/**
 * Public Order Submission API
 *
 * Called from public store product pages when a customer places an order.
 * - Rate limited to prevent spam
 * - Validates phone format
 * - Returns a tracking ID
 *
 * In production, this would:
 * 1. Look up or create buyer by phone
 * 2. Check anti-duplicate logic against existing orders
 * 3. Check buyer blacklist
 * 4. Create pending order
 * 5. Send Telegram notification to store owner
 */

interface PublicOrderPayload {
  storeSlug: string
  productId: string
  buyerName: string
  buyerPhone: string
  governorate: string
  district: string
  landmark: string
  quantity: number
  notes?: string
}

function validatePayload(body: unknown): { valid: true; data: PublicOrderPayload } | { valid: false; error: string } {
  if (!body || typeof body !== 'object') return { valid: false, error: 'Invalid body' }
  const b = body as Record<string, unknown>

  const required = ['storeSlug', 'productId', 'buyerName', 'buyerPhone', 'governorate', 'district', 'landmark', 'quantity']
  for (const field of required) {
    if (b[field] === undefined || b[field] === null || b[field] === '') {
      return { valid: false, error: `${field} is required` }
    }
  }

  if (typeof b.quantity !== 'number' || b.quantity < 1 || b.quantity > 100) {
    return { valid: false, error: 'Quantity must be between 1 and 100' }
  }

  if (!validatePhone(String(b.buyerPhone))) {
    return { valid: false, error: 'Invalid phone number format' }
  }

  if (String(b.buyerName).length < 2 || String(b.buyerName).length > 100) {
    return { valid: false, error: 'Name must be 2-100 characters' }
  }

  return {
    valid: true,
    data: {
      storeSlug: String(b.storeSlug),
      productId: String(b.productId),
      buyerName: String(b.buyerName).trim(),
      buyerPhone: normalizePhone(String(b.buyerPhone)),
      governorate: String(b.governorate).trim(),
      district: String(b.district).trim(),
      landmark: String(b.landmark).trim(),
      quantity: b.quantity,
      notes: b.notes ? String(b.notes).trim() : undefined,
    },
  }
}

export async function POST(req: NextRequest) {
  // Rate limiting by IP
  const identifier = getClientIdentifier(req)
  const rl = checkRateLimit(`public-order:${identifier}`, RATE_LIMITS.publicOrder)

  if (!rl.allowed) {
    return NextResponse.json(
      { error: 'Too many requests', resetAt: rl.resetAt },
      {
        status: 429,
        headers: {
          'X-RateLimit-Limit': String(rl.limit),
          'X-RateLimit-Remaining': '0',
          'X-RateLimit-Reset': String(Math.ceil(rl.resetAt / 1000)),
          'Retry-After': String(Math.ceil((rl.resetAt - Date.now()) / 1000)),
        },
      }
    )
  }

  const body = await req.json().catch(() => null)
  const validation = validatePayload(body)

  if (!validation.valid) {
    return NextResponse.json({ error: validation.error }, { status: 400 })
  }

  // In production: database operations, duplicate check, buyer blacklist
  const orderId = `order-${Date.now()}-${Math.random().toString(36).substring(2, 8)}`

  return NextResponse.json(
    {
      success: true,
      orderId,
      status: 'pending',
      message: 'Order received. You will be contacted for confirmation.',
    },
    {
      status: 201,
      headers: {
        'X-RateLimit-Limit': String(rl.limit),
        'X-RateLimit-Remaining': String(rl.remaining),
        'X-RateLimit-Reset': String(Math.ceil(rl.resetAt / 1000)),
      },
    }
  )
}

export async function OPTIONS() {
  return new Response(null, {
    status: 204,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    },
  })
}
