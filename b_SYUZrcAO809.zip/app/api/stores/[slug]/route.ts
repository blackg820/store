import { NextRequest, NextResponse } from 'next/server'

// Public API for store information
// Useful for mobile apps and external integrations

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ slug: string }> }
) {
  const { slug } = await params

  // In production, this would query the database
  // For demo, return a structured response

  return NextResponse.json({
    success: true,
    message: 'Store API endpoint. Connect to database for real data.',
    slug,
    endpoints: {
      store: 'GET /api/stores/:slug',
      products: 'GET /api/stores/:slug/products',
      order: 'POST /api/stores/:slug/order',
    },
    example: {
      id: 'store-1',
      name: 'Example Store',
      nameAr: 'متجر مثال',
      slug,
      isActive: true,
      products: [],
    },
  })
}
