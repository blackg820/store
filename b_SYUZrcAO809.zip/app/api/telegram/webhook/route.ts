import { NextResponse, type NextRequest } from 'next/server'
import { sendTelegramMessage } from '@/lib/telegram'

/**
 * Telegram Bot Webhook Handler
 *
 * Receives updates from Telegram Bot API.
 * Handles /start command with linking tokens for store setup.
 *
 * Setup:
 * 1. Set TELEGRAM_BOT_TOKEN env var
 * 2. Register webhook: https://api.telegram.org/bot<TOKEN>/setWebhook?url=https://your-domain.com/api/telegram/webhook
 * 3. Store owner generates linking token in dashboard
 * 4. Store owner clicks t.me/YourBot?start=TOKEN
 * 5. Bot receives /start TOKEN and links chat_id to store
 */

interface TelegramUpdate {
  update_id: number
  message?: {
    message_id: number
    from?: { id: number; first_name: string; username?: string }
    chat: { id: number; type: 'private' | 'group' | 'supergroup' | 'channel' }
    text?: string
  }
}

// In production, this should be persisted. For now, tokens are in memory.
// Tokens are validated against the database to link chat_id to the store.
const linkingTokens = new Map<string, { storeId: string; type: 'user' | 'group'; expiresAt: number }>()

export function registerLinkingToken(
  token: string,
  storeId: string,
  type: 'user' | 'group'
) {
  linkingTokens.set(token, {
    storeId,
    type,
    expiresAt: Date.now() + 15 * 60 * 1000, // 15 min
  })
}

export async function POST(req: NextRequest) {
  try {
    const update = (await req.json()) as TelegramUpdate
    const message = update.message

    if (!message?.text) {
      return NextResponse.json({ ok: true })
    }

    // Handle /start command with linking token
    if (message.text.startsWith('/start')) {
      const parts = message.text.split(' ')
      const token = parts[1]

      if (!token) {
        await sendTelegramMessage({
          chatId: String(message.chat.id),
          text: '👋 Welcome to Storify Bot!\n\nTo link this chat to your store, generate a linking link from your store dashboard under Settings → Telegram.',
        })
        return NextResponse.json({ ok: true })
      }

      const link = linkingTokens.get(token)
      if (!link || link.expiresAt < Date.now()) {
        await sendTelegramMessage({
          chatId: String(message.chat.id),
          text: '⚠️ This linking token is invalid or has expired. Please generate a new one from your dashboard.',
        })
        return NextResponse.json({ ok: true })
      }

      // Validate chat type matches link type
      const isGroup = message.chat.type === 'group' || message.chat.type === 'supergroup'
      if (link.type === 'group' && !isGroup) {
        await sendTelegramMessage({
          chatId: String(message.chat.id),
          text: '⚠️ This token is for a group. Please add the bot to your group and run /start there.',
        })
        return NextResponse.json({ ok: true })
      }
      if (link.type === 'user' && isGroup) {
        await sendTelegramMessage({
          chatId: String(message.chat.id),
          text: '⚠️ This token is for a private chat. Please send /start in a private chat with the bot.',
        })
        return NextResponse.json({ ok: true })
      }

      // In production: save chat_id to store in DB
      linkingTokens.delete(token)

      await sendTelegramMessage({
        chatId: String(message.chat.id),
        text: `✅ Successfully linked!\n\nYour ${link.type === 'group' ? 'group' : 'account'} is now connected to your store. You will receive order notifications and alerts here.\n\nStore ID: ${link.storeId}`,
      })

      return NextResponse.json({ ok: true, storeId: link.storeId, chatId: message.chat.id })
    }

    // Default response for other messages
    await sendTelegramMessage({
      chatId: String(message.chat.id),
      text: 'Use /start <token> to link this chat to your store.',
    })

    return NextResponse.json({ ok: true })
  } catch (error) {
    console.error('[Telegram Webhook] Error:', error)
    return NextResponse.json({ ok: false, error: 'Internal error' }, { status: 500 })
  }
}

// GET endpoint to check webhook status
export async function GET() {
  return NextResponse.json({
    status: 'Telegram webhook is active',
    setup: 'POST updates to this endpoint from Telegram',
    docs: 'https://core.telegram.org/bots/api#setwebhook',
  })
}
