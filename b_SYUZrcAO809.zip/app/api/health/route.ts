import { NextResponse } from 'next/server'
import { isBunnyConfigured } from '@/lib/bunny-cdn'
import { isTelegramConfigured } from '@/lib/telegram'

/**
 * Health check endpoint for monitoring and uptime checks.
 * Returns status of all integrations.
 */
export async function GET() {
  const checks = {
    api: 'healthy',
    database: process.env.DATABASE_URL ? 'configured' : 'not-configured',
    bunny_cdn: isBunnyConfigured() ? 'configured' : 'not-configured',
    telegram: isTelegramConfigured() ? 'configured' : 'not-configured',
    timestamp: new Date().toISOString(),
    version: '1.0.0',
  }

  return NextResponse.json(
    {
      status: 'ok',
      checks,
    },
    {
      status: 200,
      headers: {
        'Cache-Control': 'no-store',
      },
    }
  )
}
