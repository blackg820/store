import { NextRequest, NextResponse } from 'next/server'
import { mockBuyers } from '@/lib/mock-data'
import { verifyToken, extractTokenFromHeader, successResponse, errorResponse, paginatedResponse } from '@/lib/jwt'

// GET /api/v1/buyers - List buyers or lookup by phone
export async function GET(request: NextRequest) {
  try {
    const token = extractTokenFromHeader(request.headers.get('Authorization'))
    
    if (!token) {
      return NextResponse.json(errorResponse('Authorization required'), { status: 401 })
    }

    const payload = verifyToken(token)
    if (!payload || payload.type !== 'access') {
      return NextResponse.json(errorResponse('Invalid or expired token'), { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const phone = searchParams.get('phone')
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '10')
    const riskLevel = searchParams.get('risk_level')
    const blacklisted = searchParams.get('blacklisted')

    // Phone lookup - exact match
    if (phone) {
      const buyer = mockBuyers.find(b => b.phone === phone)
      if (buyer) {
        return NextResponse.json(successResponse(buyer))
      }
      return NextResponse.json(errorResponse('Buyer not found'), { status: 404 })
    }

    let buyers = [...mockBuyers]

    // Apply filters
    if (riskLevel) {
      buyers = buyers.filter(b => b.riskScore === riskLevel)
    }
    if (blacklisted !== null && blacklisted !== undefined) {
      buyers = buyers.filter(b => b.isBlacklisted === (blacklisted === 'true'))
    }

    const total = buyers.length
    const paginatedBuyers = buyers.slice((page - 1) * limit, page * limit)

    return NextResponse.json(paginatedResponse(paginatedBuyers, page, limit, total))
  } catch (error) {
    return NextResponse.json(errorResponse('Internal server error'), { status: 500 })
  }
}

// POST /api/v1/buyers - Create buyer
export async function POST(request: NextRequest) {
  try {
    const token = extractTokenFromHeader(request.headers.get('Authorization'))
    
    if (!token) {
      return NextResponse.json(errorResponse('Authorization required'), { status: 401 })
    }

    const payload = verifyToken(token)
    if (!payload || payload.type !== 'access') {
      return NextResponse.json(errorResponse('Invalid or expired token'), { status: 401 })
    }

    const body = await request.json()
    const { phone, name, governorate, district, landmark } = body

    if (!phone || !name || !governorate || !district) {
      return NextResponse.json(
        errorResponse('phone, name, governorate, and district are required'),
        { status: 400 }
      )
    }

    // Check if phone already exists
    const existingBuyer = mockBuyers.find(b => b.phone === phone)
    if (existingBuyer) {
      return NextResponse.json(
        errorResponse('Buyer with this phone already exists'),
        { status: 409 }
      )
    }

    const newBuyer = {
      id: `buyer-${Date.now()}`,
      phone,
      name,
      governorate,
      district,
      landmark: landmark || '',
      totalOrders: 0,
      rejectedOrders: 0,
      riskScore: 'low' as const,
      isBlacklisted: false,
      createdAt: new Date().toISOString(),
    }

    return NextResponse.json(
      successResponse(newBuyer, 'Buyer created successfully'),
      { status: 201 }
    )
  } catch (error) {
    return NextResponse.json(errorResponse('Internal server error'), { status: 500 })
  }
}
