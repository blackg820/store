import { NextRequest, NextResponse } from 'next/server'
import { mockOrders, mockStores, mockProducts, mockBuyers } from '@/lib/mock-data'
import { verifyToken, extractTokenFromHeader, successResponse, errorResponse } from '@/lib/jwt'

// GET /api/v1/analytics - Get analytics data
export async function GET(request: NextRequest) {
  try {
    const token = extractTokenFromHeader(request.headers.get('Authorization'))
    
    if (!token) {
      return NextResponse.json(errorResponse('Authorization required'), { status: 401 })
    }

    const payload = verifyToken(token)
    if (!payload || payload.type !== 'access') {
      return NextResponse.json(errorResponse('Invalid or expired token'), { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const storeId = searchParams.get('store_id')
    const period = searchParams.get('period') || '30' // days

    // Get user's stores
    const userStores = payload.role === 'admin'
      ? mockStores
      : mockStores.filter(s => s.userId === payload.userId)
    const userStoreIds = userStores.map(s => s.id)

    // Filter orders by user's stores and optionally by specific store
    let orders = mockOrders.filter(o => userStoreIds.includes(o.storeId))
    if (storeId && userStoreIds.includes(storeId)) {
      orders = orders.filter(o => o.storeId === storeId)
    }

    // Filter by period
    const periodDays = parseInt(period)
    const startDate = new Date()
    startDate.setDate(startDate.getDate() - periodDays)
    orders = orders.filter(o => new Date(o.createdAt) >= startDate)

    // Calculate analytics
    const totalOrders = orders.length
    const pendingOrders = orders.filter(o => o.status === 'pending').length
    const confirmedOrders = orders.filter(o => o.status === 'confirmed').length
    const deliveredOrders = orders.filter(o => o.status === 'delivered').length
    const returnedOrders = orders.filter(o => o.status === 'returned').length
    const problematicOrders = orders.filter(o => o.status === 'problematic').length

    const totalRevenue = orders
      .filter(o => o.status === 'delivered')
      .reduce((sum, o) => sum + o.totalPrice, 0)

    const averageOrderValue = deliveredOrders > 0 ? totalRevenue / deliveredOrders : 0

    // Order status distribution
    const statusDistribution = {
      pending: pendingOrders,
      confirmed: confirmedOrders,
      delivered: deliveredOrders,
      returned: returnedOrders,
      problematic: problematicOrders,
    }

    // Conversion rate
    const conversionRate = totalOrders > 0 ? (deliveredOrders / totalOrders) * 100 : 0

    // Return rate
    const returnRate = totalOrders > 0 ? ((returnedOrders + problematicOrders) / totalOrders) * 100 : 0

    // Top products by orders
    const productOrderCounts: Record<string, number> = {}
    orders.forEach(o => {
      productOrderCounts[o.productId] = (productOrderCounts[o.productId] || 0) + 1
    })
    const topProducts = Object.entries(productOrderCounts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([productId, count]) => {
        const product = mockProducts.find(p => p.id === productId)
        return {
          id: productId,
          name: product?.name || 'Unknown',
          nameAr: product?.nameAr || 'غير معروف',
          orderCount: count,
        }
      })

    // Daily orders for chart
    const dailyOrders: Record<string, { orders: number; revenue: number }> = {}
    orders.forEach(o => {
      const date = o.createdAt.split('T')[0]
      if (!dailyOrders[date]) {
        dailyOrders[date] = { orders: 0, revenue: 0 }
      }
      dailyOrders[date].orders++
      if (o.status === 'delivered') {
        dailyOrders[date].revenue += o.totalPrice
      }
    })

    // Store performance (for admin or multi-store owners)
    const storePerformance = userStores.map(store => {
      const storeOrders = orders.filter(o => o.storeId === store.id)
      const storeProducts = mockProducts.filter(p => p.storeId === store.id)
      const storeRevenue = storeOrders
        .filter(o => o.status === 'delivered')
        .reduce((sum, o) => sum + o.totalPrice, 0)

      return {
        id: store.id,
        name: store.name,
        nameAr: store.nameAr,
        totalOrders: storeOrders.length,
        totalProducts: storeProducts.length,
        revenue: storeRevenue,
        isActive: store.isActive,
      }
    })

    // Buyer risk distribution
    const riskDistribution = {
      low: mockBuyers.filter(b => b.riskScore === 'low').length,
      medium: mockBuyers.filter(b => b.riskScore === 'medium').length,
      high: mockBuyers.filter(b => b.riskScore === 'high').length,
      blacklisted: mockBuyers.filter(b => b.isBlacklisted).length,
    }

    return NextResponse.json(successResponse({
      period: periodDays,
      summary: {
        totalOrders,
        totalRevenue: Math.round(totalRevenue * 100) / 100,
        averageOrderValue: Math.round(averageOrderValue * 100) / 100,
        conversionRate: Math.round(conversionRate * 10) / 10,
        returnRate: Math.round(returnRate * 10) / 10,
        totalStores: userStores.length,
        totalProducts: mockProducts.filter(p => userStoreIds.includes(p.storeId)).length,
        totalBuyers: mockBuyers.length,
      },
      statusDistribution,
      topProducts,
      dailyOrders: Object.entries(dailyOrders).map(([date, data]) => ({
        date,
        ...data,
      })),
      storePerformance,
      riskDistribution,
    }))
  } catch (error) {
    return NextResponse.json(errorResponse('Internal server error'), { status: 500 })
  }
}
