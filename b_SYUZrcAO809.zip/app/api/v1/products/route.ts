import { NextRequest, NextResponse } from 'next/server'
import { mockProducts, mockStores, mockSubscriptions, mockUsers, mockProductTypes, mockCategories } from '@/lib/mock-data'
import { verifyToken, extractTokenFromHeader, successResponse, errorResponse, paginatedResponse } from '@/lib/jwt'
import { PLAN_LIMITS } from '@/lib/types'

// GET /api/v1/products - List products
export async function GET(request: NextRequest) {
  try {
    const token = extractTokenFromHeader(request.headers.get('Authorization'))
    
    if (!token) {
      return NextResponse.json(errorResponse('Authorization required'), { status: 401 })
    }

    const payload = verifyToken(token)
    if (!payload || payload.type !== 'access') {
      return NextResponse.json(errorResponse('Invalid or expired token'), { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '10')
    const storeId = searchParams.get('store_id')
    const categoryId = searchParams.get('category_id')
    const productTypeId = searchParams.get('product_type_id')
    const search = searchParams.get('search') || ''
    const minPrice = parseFloat(searchParams.get('min_price') || '0')
    const maxPrice = parseFloat(searchParams.get('max_price') || '999999')

    // Get user's stores
    const userStores = payload.role === 'admin'
      ? mockStores
      : mockStores.filter(s => s.userId === payload.userId)
    const userStoreIds = userStores.map(s => s.id)

    let products = mockProducts.filter(p => userStoreIds.includes(p.storeId))

    // Apply filters
    if (storeId) {
      products = products.filter(p => p.storeId === storeId)
    }
    if (categoryId) {
      products = products.filter(p => p.categoryId === categoryId)
    }
    if (productTypeId) {
      products = products.filter(p => p.productTypeId === productTypeId)
    }
    if (search) {
      const searchLower = search.toLowerCase()
      products = products.filter(p =>
        p.name.toLowerCase().includes(searchLower) ||
        p.nameAr.includes(search) ||
        p.description.toLowerCase().includes(searchLower)
      )
    }
    products = products.filter(p => p.price >= minPrice && p.price <= maxPrice)

    const total = products.length
    const paginatedProducts = products.slice((page - 1) * limit, page * limit)

    // Enrich with store info
    const enrichedProducts = paginatedProducts.map(p => ({
      ...p,
      store: userStores.find(s => s.id === p.storeId),
      productType: mockProductTypes.find(pt => pt.id === p.productTypeId),
      category: mockCategories.find(c => c.id === p.categoryId),
    }))

    return NextResponse.json(paginatedResponse(enrichedProducts, page, limit, total))
  } catch (error) {
    return NextResponse.json(errorResponse('Internal server error'), { status: 500 })
  }
}

// POST /api/v1/products - Create product
export async function POST(request: NextRequest) {
  try {
    const token = extractTokenFromHeader(request.headers.get('Authorization'))
    
    if (!token) {
      return NextResponse.json(errorResponse('Authorization required'), { status: 401 })
    }

    const payload = verifyToken(token)
    if (!payload || payload.type !== 'access') {
      return NextResponse.json(errorResponse('Invalid or expired token'), { status: 401 })
    }

    const body = await request.json()
    const { 
      storeId, productTypeId, categoryId, name, nameAr, 
      description, descriptionAr, price, discount, discountEndDate,
      customData, images, videos 
    } = body

    if (!storeId || !name || !nameAr || !price) {
      return NextResponse.json(
        errorResponse('storeId, name, nameAr, and price are required'),
        { status: 400 }
      )
    }

    // Verify store ownership
    const store = mockStores.find(s => s.id === storeId)
    if (!store || (payload.role !== 'admin' && store.userId !== payload.userId)) {
      return NextResponse.json(errorResponse('Store not found or access denied'), { status: 403 })
    }

    // Check plan limits (only for controlled mode)
    const user = mockUsers.find(u => u.id === payload.userId)
    if (user?.mode === 'controlled') {
      const subscription = mockSubscriptions.find(s => s.userId === payload.userId && s.isActive)
      if (subscription) {
        const limits = PLAN_LIMITS[subscription.plan]
        const storeProducts = mockProducts.filter(p => p.storeId === storeId)
        
        if (storeProducts.length >= limits.productsPerStore) {
          return NextResponse.json(
            errorResponse(`Product limit reached for ${subscription.plan} plan (${limits.productsPerStore} products per store)`),
            { status: 403 }
          )
        }
      }
    }

    // Validate custom data against product type schema
    if (productTypeId && customData) {
      const productType = mockProductTypes.find(pt => pt.id === productTypeId)
      if (productType) {
        for (const field of productType.customFields) {
          if (field.required && !(field.name in customData)) {
            return NextResponse.json(
              errorResponse(`Missing required field: ${field.name}`),
              { status: 400 }
            )
          }
        }
      }
    }

    const newProduct = {
      id: `prod-${Date.now()}`,
      storeId,
      productTypeId,
      categoryId,
      name,
      nameAr,
      description: description || '',
      descriptionAr: descriptionAr || '',
      price: parseFloat(price),
      discount: discount ? parseFloat(discount) : undefined,
      discountEndDate,
      images: images || [],
      videos: videos || [],
      customData,
      isActive: true,
      createdAt: new Date().toISOString(),
      averageRating: 0,
      totalRatings: 0,
    }

    return NextResponse.json(
      successResponse(newProduct, 'Product created successfully'),
      { status: 201 }
    )
  } catch (error) {
    return NextResponse.json(errorResponse('Internal server error'), { status: 500 })
  }
}
