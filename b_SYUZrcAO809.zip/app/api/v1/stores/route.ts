import { NextRequest, NextResponse } from 'next/server'
import { mockStores, mockUsers, mockSubscriptions } from '@/lib/mock-data'
import { verifyToken, extractTokenFromHeader, successResponse, errorResponse, paginatedResponse } from '@/lib/jwt'
import { PLAN_LIMITS } from '@/lib/types'

// GET /api/v1/stores - List stores
export async function GET(request: NextRequest) {
  try {
    const token = extractTokenFromHeader(request.headers.get('Authorization'))
    
    if (!token) {
      return NextResponse.json(errorResponse('Authorization required'), { status: 401 })
    }

    const payload = verifyToken(token)
    if (!payload || payload.type !== 'access') {
      return NextResponse.json(errorResponse('Invalid or expired token'), { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '10')
    const search = searchParams.get('search') || ''

    let stores = payload.role === 'admin' 
      ? mockStores 
      : mockStores.filter(s => s.userId === payload.userId)

    // Apply search filter
    if (search) {
      const searchLower = search.toLowerCase()
      stores = stores.filter(s => 
        s.name.toLowerCase().includes(searchLower) ||
        s.nameAr.includes(search) ||
        s.slug.toLowerCase().includes(searchLower)
      )
    }

    const total = stores.length
    const paginatedStores = stores.slice((page - 1) * limit, page * limit)

    return NextResponse.json(paginatedResponse(paginatedStores, page, limit, total))
  } catch (error) {
    return NextResponse.json(errorResponse('Internal server error'), { status: 500 })
  }
}

// POST /api/v1/stores - Create store
export async function POST(request: NextRequest) {
  try {
    const token = extractTokenFromHeader(request.headers.get('Authorization'))
    
    if (!token) {
      return NextResponse.json(errorResponse('Authorization required'), { status: 401 })
    }

    const payload = verifyToken(token)
    if (!payload || payload.type !== 'access') {
      return NextResponse.json(errorResponse('Invalid or expired token'), { status: 401 })
    }

    const body = await request.json()
    const { name, nameAr, slug, description, descriptionAr } = body

    if (!name || !nameAr || !slug) {
      return NextResponse.json(errorResponse('Name, nameAr, and slug are required'), { status: 400 })
    }

    // Check slug uniqueness
    if (mockStores.some(s => s.slug === slug)) {
      return NextResponse.json(errorResponse('Slug already exists'), { status: 409 })
    }

    // Check plan limits (only for controlled mode)
    const user = mockUsers.find(u => u.id === payload.userId)
    if (user?.mode === 'controlled') {
      const subscription = mockSubscriptions.find(s => s.userId === payload.userId && s.isActive)
      if (subscription) {
        const limits = PLAN_LIMITS[subscription.plan]
        const userStores = mockStores.filter(s => s.userId === payload.userId)
        
        if (userStores.length >= limits.stores) {
          return NextResponse.json(
            errorResponse(`Store limit reached for ${subscription.plan} plan (${limits.stores} stores)`),
            { status: 403 }
          )
        }
      }
    }

    const newStore = {
      id: `store-${Date.now()}`,
      userId: payload.userId,
      name,
      nameAr,
      slug,
      description: description || '',
      descriptionAr: descriptionAr || '',
      isActive: true,
      createdAt: new Date().toISOString(),
    }

    // In production, save to database
    // mockStores.push(newStore)

    return NextResponse.json(
      successResponse(newStore, 'Store created successfully'),
      { status: 201 }
    )
  } catch (error) {
    return NextResponse.json(errorResponse('Internal server error'), { status: 500 })
  }
}
