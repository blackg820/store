import { NextRequest, NextResponse } from 'next/server'
import { mockUsers } from '@/lib/mock-data'
import { generateAccessToken, generateRefreshToken, successResponse, errorResponse } from '@/lib/jwt'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { email, password } = body

    if (!email || !password) {
      return NextResponse.json(
        errorResponse('Email and password are required'),
        { status: 400 }
      )
    }

    // In production, verify password hash with bcrypt
    const user = mockUsers.find(u => u.email === email && u.isActive)
    
    // Mock password check (demo123 for all users)
    if (!user || password !== 'demo123') {
      return NextResponse.json(
        errorResponse('Invalid credentials'),
        { status: 401 }
      )
    }

    const accessToken = generateAccessToken(user)
    const refreshToken = generateRefreshToken(user)

    return NextResponse.json(
      successResponse({
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role,
          mode: user.mode,
        },
        accessToken,
        refreshToken,
        expiresIn: 15 * 60, // 15 minutes in seconds
      }, 'Login successful')
    )
  } catch (error) {
    return NextResponse.json(
      errorResponse('Internal server error'),
      { status: 500 }
    )
  }
}
