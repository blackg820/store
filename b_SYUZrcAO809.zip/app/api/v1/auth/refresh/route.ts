import { NextRequest, NextResponse } from 'next/server'
import { mockUsers } from '@/lib/mock-data'
import { verifyToken, generateAccessToken, generateRefreshToken, successResponse, errorResponse } from '@/lib/jwt'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { refreshToken } = body

    if (!refreshToken) {
      return NextResponse.json(
        errorResponse('Refresh token is required'),
        { status: 400 }
      )
    }

    const payload = verifyToken(refreshToken)
    
    if (!payload || payload.type !== 'refresh') {
      return NextResponse.json(
        errorResponse('Invalid or expired refresh token'),
        { status: 401 }
      )
    }

    const user = mockUsers.find(u => u.id === payload.userId && u.isActive)
    
    if (!user) {
      return NextResponse.json(
        errorResponse('User not found or inactive'),
        { status: 401 }
      )
    }

    const newAccessToken = generateAccessToken(user)
    const newRefreshToken = generateRefreshToken(user)

    return NextResponse.json(
      successResponse({
        accessToken: newAccessToken,
        refreshToken: newRefreshToken,
        expiresIn: 15 * 60,
      }, 'Token refreshed successfully')
    )
  } catch (error) {
    return NextResponse.json(
      errorResponse('Internal server error'),
      { status: 500 }
    )
  }
}
