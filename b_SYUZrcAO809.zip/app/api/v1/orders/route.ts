import { NextRequest, NextResponse } from 'next/server'
import { mockOrders, mockStores, mockProducts, mockBuyers } from '@/lib/mock-data'
import { verifyToken, extractTokenFromHeader, successResponse, errorResponse, paginatedResponse } from '@/lib/jwt'
import type { OrderStatus } from '@/lib/types'

// GET /api/v1/orders - List orders
export async function GET(request: NextRequest) {
  try {
    const token = extractTokenFromHeader(request.headers.get('Authorization'))
    
    if (!token) {
      return NextResponse.json(errorResponse('Authorization required'), { status: 401 })
    }

    const payload = verifyToken(token)
    if (!payload || payload.type !== 'access') {
      return NextResponse.json(errorResponse('Invalid or expired token'), { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '10')
    const storeId = searchParams.get('store_id')
    const status = searchParams.get('status') as OrderStatus | null
    const buyerId = searchParams.get('buyer_id')
    const startDate = searchParams.get('start_date')
    const endDate = searchParams.get('end_date')

    // Get user's stores
    const userStores = payload.role === 'admin'
      ? mockStores
      : mockStores.filter(s => s.userId === payload.userId)
    const userStoreIds = userStores.map(s => s.id)

    let orders = mockOrders.filter(o => userStoreIds.includes(o.storeId))

    // Apply filters
    if (storeId) {
      orders = orders.filter(o => o.storeId === storeId)
    }
    if (status) {
      orders = orders.filter(o => o.status === status)
    }
    if (buyerId) {
      orders = orders.filter(o => o.buyerId === buyerId)
    }
    if (startDate) {
      orders = orders.filter(o => new Date(o.createdAt) >= new Date(startDate))
    }
    if (endDate) {
      orders = orders.filter(o => new Date(o.createdAt) <= new Date(endDate))
    }

    // Sort by date descending
    orders.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())

    const total = orders.length
    const paginatedOrders = orders.slice((page - 1) * limit, page * limit)

    // Enrich with related data
    const enrichedOrders = paginatedOrders.map(o => ({
      ...o,
      store: userStores.find(s => s.id === o.storeId),
      product: mockProducts.find(p => p.id === o.productId),
      buyer: mockBuyers.find(b => b.id === o.buyerId),
    }))

    return NextResponse.json(paginatedResponse(enrichedOrders, page, limit, total))
  } catch (error) {
    return NextResponse.json(errorResponse('Internal server error'), { status: 500 })
  }
}

// POST /api/v1/orders - Create order
export async function POST(request: NextRequest) {
  try {
    const token = extractTokenFromHeader(request.headers.get('Authorization'))
    
    if (!token) {
      return NextResponse.json(errorResponse('Authorization required'), { status: 401 })
    }

    const payload = verifyToken(token)
    if (!payload || payload.type !== 'access') {
      return NextResponse.json(errorResponse('Invalid or expired token'), { status: 401 })
    }

    const body = await request.json()
    const { storeId, productId, buyerId, quantity, notes } = body

    if (!storeId || !productId || !buyerId) {
      return NextResponse.json(
        errorResponse('storeId, productId, and buyerId are required'),
        { status: 400 }
      )
    }

    // Verify store ownership
    const store = mockStores.find(s => s.id === storeId)
    if (!store || (payload.role !== 'admin' && store.userId !== payload.userId)) {
      return NextResponse.json(errorResponse('Store not found or access denied'), { status: 403 })
    }

    // Verify product exists and belongs to store
    const product = mockProducts.find(p => p.id === productId && p.storeId === storeId)
    if (!product) {
      return NextResponse.json(errorResponse('Product not found in store'), { status: 404 })
    }

    // Check if buyer is blacklisted
    const buyer = mockBuyers.find(b => b.id === buyerId)
    if (buyer?.isBlacklisted) {
      return NextResponse.json(errorResponse('Buyer is blacklisted'), { status: 403 })
    }

    // Calculate price with discounts
    let unitPrice = product.price
    if (product.discount && (!product.discountEndDate || new Date(product.discountEndDate) > new Date())) {
      unitPrice = unitPrice * (1 - product.discount / 100)
    }
    if (store.globalDiscount && (!store.globalDiscountEndDate || new Date(store.globalDiscountEndDate) > new Date())) {
      unitPrice = unitPrice * (1 - store.globalDiscount / 100)
    }

    const qty = quantity || 1
    const totalPrice = unitPrice * qty

    const newOrder = {
      id: `order-${Date.now()}`,
      storeId,
      productId,
      buyerId,
      quantity: qty,
      totalPrice: Math.round(totalPrice * 100) / 100,
      status: 'pending' as OrderStatus,
      notes: notes || '',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }

    return NextResponse.json(
      successResponse(newOrder, 'Order created successfully'),
      { status: 201 }
    )
  } catch (error) {
    return NextResponse.json(errorResponse('Internal server error'), { status: 500 })
  }
}
