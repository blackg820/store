import { NextRequest, NextResponse } from 'next/server'
import { mockOrders, mockStores, mockBuyers } from '@/lib/mock-data'
import { verifyToken, extractTokenFromHeader, successResponse, errorResponse } from '@/lib/jwt'
import type { OrderStatus } from '@/lib/types'

const VALID_STATUS_TRANSITIONS: Record<OrderStatus, OrderStatus[]> = {
  pending: ['confirmed', 'problematic'],
  confirmed: ['delivered', 'returned', 'problematic'],
  delivered: ['returned'],
  returned: [],
  problematic: ['confirmed', 'returned'],
}

// PATCH /api/v1/orders/[id]/status - Update order status
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const token = extractTokenFromHeader(request.headers.get('Authorization'))
    
    if (!token) {
      return NextResponse.json(errorResponse('Authorization required'), { status: 401 })
    }

    const payload = verifyToken(token)
    if (!payload || payload.type !== 'access') {
      return NextResponse.json(errorResponse('Invalid or expired token'), { status: 401 })
    }

    const body = await request.json()
    const { status, internalNotes } = body

    if (!status) {
      return NextResponse.json(errorResponse('Status is required'), { status: 400 })
    }

    const validStatuses: OrderStatus[] = ['pending', 'confirmed', 'delivered', 'returned', 'problematic']
    if (!validStatuses.includes(status)) {
      return NextResponse.json(errorResponse('Invalid status'), { status: 400 })
    }

    // Find order
    const order = mockOrders.find(o => o.id === id)
    if (!order) {
      return NextResponse.json(errorResponse('Order not found'), { status: 404 })
    }

    // Verify store ownership
    const store = mockStores.find(s => s.id === order.storeId)
    if (!store || (payload.role !== 'admin' && store.userId !== payload.userId)) {
      return NextResponse.json(errorResponse('Access denied'), { status: 403 })
    }

    // Validate status transition
    const allowedTransitions = VALID_STATUS_TRANSITIONS[order.status]
    if (!allowedTransitions.includes(status)) {
      return NextResponse.json(
        errorResponse(`Cannot transition from ${order.status} to ${status}`),
        { status: 400 }
      )
    }

    // Update buyer risk score if returned/problematic
    if (status === 'returned' || status === 'problematic') {
      const buyer = mockBuyers.find(b => b.id === order.buyerId)
      if (buyer) {
        const newRejected = buyer.rejectedOrders + 1
        const ratio = newRejected / buyer.totalOrders
        const riskScore = ratio > 0.5 ? 'high' : ratio > 0.2 ? 'medium' : 'low'
        // In production, update buyer in database
        console.log(`[v0] Updated buyer ${buyer.id} risk score to ${riskScore}`)
      }
    }

    // Create audit log entry
    const auditLog = {
      id: `log-${Date.now()}`,
      orderId: id,
      action: 'status_change',
      previousValue: order.status,
      newValue: status,
      performedBy: payload.userId,
      performedAt: new Date().toISOString(),
    }

    const updatedOrder = {
      ...order,
      status,
      updatedAt: new Date().toISOString(),
    }

    return NextResponse.json(
      successResponse({
        order: updatedOrder,
        auditLog,
      }, `Order status updated to ${status}`)
    )
  } catch (error) {
    return NextResponse.json(errorResponse('Internal server error'), { status: 500 })
  }
}
