import { NextRequest, NextResponse } from 'next/server'
import { mockMedia, mockProducts, mockStores } from '@/lib/mock-data'
import { verifyToken, extractTokenFromHeader, successResponse, errorResponse } from '@/lib/jwt'

// GET /api/v1/media/[id] - Get media with access control
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const { searchParams } = new URL(request.url)
    const signedToken = searchParams.get('token')

    const media = mockMedia.find(m => m.id === id)
    if (!media) {
      return NextResponse.json(errorResponse('Media not found'), { status: 404 })
    }

    // Public media - no auth required
    if (media.visibility === 'public') {
      return NextResponse.json(successResponse({
        id: media.id,
        url: media.url,
        type: media.type,
        visibility: media.visibility,
        size: media.size,
      }))
    }

    // Private/Restricted media - requires auth or signed URL
    const token = extractTokenFromHeader(request.headers.get('Authorization'))
    
    if (!token && !signedToken) {
      return NextResponse.json(errorResponse('Authorization required'), { status: 401 })
    }

    // Verify JWT token
    if (token) {
      const payload = verifyToken(token)
      if (!payload || payload.type !== 'access') {
        return NextResponse.json(errorResponse('Invalid token'), { status: 401 })
      }

      // Verify ownership
      const product = mockProducts.find(p => p.id === media.productId)
      if (!product) {
        return NextResponse.json(errorResponse('Product not found'), { status: 404 })
      }

      const store = mockStores.find(s => s.id === product.storeId)
      if (!store || (payload.role !== 'admin' && store.userId !== payload.userId)) {
        return NextResponse.json(errorResponse('Access denied'), { status: 403 })
      }
    }

    // For restricted media, provide blur hash for preview
    if (media.visibility === 'restricted') {
      return NextResponse.json(successResponse({
        id: media.id,
        url: media.url,
        type: media.type,
        visibility: media.visibility,
        blurHash: media.blurHash,
        size: media.size,
        requiresReveal: true,
      }))
    }

    // Private media - full access
    return NextResponse.json(successResponse({
      id: media.id,
      url: media.url,
      type: media.type,
      visibility: media.visibility,
      size: media.size,
      metadata: media.metadata,
    }))
  } catch (error) {
    return NextResponse.json(errorResponse('Internal server error'), { status: 500 })
  }
}

// Generate signed URL for time-limited access
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const token = extractTokenFromHeader(request.headers.get('Authorization'))
    
    if (!token) {
      return NextResponse.json(errorResponse('Authorization required'), { status: 401 })
    }

    const payload = verifyToken(token)
    if (!payload || payload.type !== 'access') {
      return NextResponse.json(errorResponse('Invalid token'), { status: 401 })
    }

    const media = mockMedia.find(m => m.id === id)
    if (!media) {
      return NextResponse.json(errorResponse('Media not found'), { status: 404 })
    }

    // Verify ownership
    const product = mockProducts.find(p => p.id === media.productId)
    if (!product) {
      return NextResponse.json(errorResponse('Product not found'), { status: 404 })
    }

    const store = mockStores.find(s => s.id === product.storeId)
    if (!store || (payload.role !== 'admin' && store.userId !== payload.userId)) {
      return NextResponse.json(errorResponse('Access denied'), { status: 403 })
    }

    // Generate time-limited signed URL (expires in 1 hour)
    const expiresAt = Date.now() + 3600000
    const signedToken = Buffer.from(`${id}:${expiresAt}:${payload.userId}`).toString('base64url')

    return NextResponse.json(successResponse({
      signedUrl: `/api/v1/media/${id}?token=${signedToken}`,
      expiresAt: new Date(expiresAt).toISOString(),
    }, 'Signed URL generated'))
  } catch (error) {
    return NextResponse.json(errorResponse('Internal server error'), { status: 500 })
  }
}
