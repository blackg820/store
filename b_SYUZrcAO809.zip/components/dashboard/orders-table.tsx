'use client'

import { useState } from 'react'
import { useData } from '@/lib/data-context'
import { useTranslations } from '@/hooks/use-translations'
import { useAuth } from '@/lib/auth-context'
import type { Order, OrderStatus } from '@/lib/types'
import { cn } from '@/lib/utils'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { MoreHorizontal, Search, Download, Plus, Eye, Edit, Trash2, AlertTriangle } from 'lucide-react'

const statusColors: Record<OrderStatus, string> = {
  pending: 'bg-warning/10 text-warning border-warning/20',
  confirmed: 'bg-primary/10 text-primary border-primary/20',
  delivered: 'bg-success/10 text-success border-success/20',
  returned: 'bg-muted text-muted-foreground border-muted',
  problematic: 'bg-destructive/10 text-destructive border-destructive/20',
}

interface OrdersTableProps {
  storeId?: string
  limit?: number
  showActions?: boolean
}

export function OrdersTable({ storeId, limit, showActions = true }: OrdersTableProps) {
  const { language } = useAuth()
  const { t } = useTranslations()
  const { orders, products, buyers, stores, updateOrderStatus, updateOrder, deleteOrder } = useData()
  
  const [searchQuery, setSearchQuery] = useState('')
  const [statusFilter, setStatusFilter] = useState<OrderStatus | 'all'>('all')
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false)
  const [editNotes, setEditNotes] = useState('')
  const [editStatus, setEditStatus] = useState<OrderStatus>('pending')

  let filteredOrders = storeId 
    ? orders.filter(o => o.storeId === storeId)
    : orders

  if (statusFilter !== 'all') {
    filteredOrders = filteredOrders.filter(o => o.status === statusFilter)
  }

  if (searchQuery) {
    filteredOrders = filteredOrders.filter(o => {
      const buyer = buyers.find(b => b.id === o.buyerId)
      const product = products.find(p => p.id === o.productId)
      return (
        o.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        buyer?.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        buyer?.phone.includes(searchQuery) ||
        product?.name.toLowerCase().includes(searchQuery.toLowerCase())
      )
    })
  }

  // Sort by date descending
  filteredOrders = [...filteredOrders].sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  )

  if (limit) {
    filteredOrders = filteredOrders.slice(0, limit)
  }

  const handleEdit = (order: Order) => {
    setSelectedOrder(order)
    setEditNotes(order.notes)
    setEditStatus(order.status)
    setIsEditDialogOpen(true)
  }

  const handleView = (order: Order) => {
    setSelectedOrder(order)
    setIsViewDialogOpen(true)
  }

  const handleSaveEdit = () => {
    if (selectedOrder) {
      updateOrder(selectedOrder.id, { notes: editNotes })
      if (editStatus !== selectedOrder.status) {
        updateOrderStatus(selectedOrder.id, editStatus)
      }
      setIsEditDialogOpen(false)
    }
  }

  const handleDelete = (orderId: string) => {
    if (confirm(t('areYouSure'))) {
      deleteOrder(orderId)
    }
  }

  const exportToCSV = () => {
    const headers = ['Order ID', 'Product', 'Buyer', 'Phone', 'Quantity', 'Total', 'Status', 'Date']
    const rows = filteredOrders.map(order => {
      const product = products.find(p => p.id === order.productId)
      const buyer = buyers.find(b => b.id === order.buyerId)
      return [
        order.id,
        product?.name || '',
        buyer?.name || '',
        buyer?.phone || '',
        order.quantity,
        order.totalPrice,
        order.status,
        new Date(order.createdAt).toLocaleDateString(),
      ]
    })
    
    const csv = [headers, ...rows].map(row => row.join(',')).join('\n')
    const blob = new Blob([csv], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'orders.csv'
    a.click()
  }

  return (
    <div className="space-y-4">
      {showActions && (
        <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
          <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
            <div className="relative">
              <Search className="absolute start-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder={t('search')}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="ps-9 w-full sm:w-64"
              />
            </div>
            <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as OrderStatus | 'all')}>
              <SelectTrigger className="w-full sm:w-40">
                <SelectValue placeholder={t('filter')} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="pending">{t('pending')}</SelectItem>
                <SelectItem value="confirmed">{t('confirmed')}</SelectItem>
                <SelectItem value="delivered">{t('delivered')}</SelectItem>
                <SelectItem value="returned">{t('returned')}</SelectItem>
                <SelectItem value="problematic">{t('problematic')}</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={exportToCSV}>
              <Download className="h-4 w-4 me-2" />
              {t('export')}
            </Button>
          </div>
        </div>
      )}

      <div className="rounded-lg border border-border bg-card overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50">
              <TableHead>Order ID</TableHead>
              <TableHead>{t('products')}</TableHead>
              <TableHead>Buyer</TableHead>
              <TableHead className="text-center">{t('quantity')}</TableHead>
              <TableHead>{t('total')}</TableHead>
              <TableHead>{t('status')}</TableHead>
              <TableHead>{t('date')}</TableHead>
              {showActions && <TableHead className="text-end">{t('actions')}</TableHead>}
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredOrders.length === 0 ? (
              <TableRow>
                <TableCell colSpan={showActions ? 8 : 7} className="text-center py-8 text-muted-foreground">
                  {t('noData')}
                </TableCell>
              </TableRow>
            ) : (
              filteredOrders.map((order) => {
                const product = products.find(p => p.id === order.productId)
                const buyer = buyers.find(b => b.id === order.buyerId)
                const store = stores.find(s => s.id === order.storeId)
                const isHighRisk = buyer?.riskScore === 'high'

                return (
                  <TableRow key={order.id} className={cn(isHighRisk && 'bg-destructive/5')}>
                    <TableCell className="font-mono text-sm">{order.id.slice(0, 8)}...</TableCell>
                    <TableCell>
                      <div>
                        <p className="font-medium">{language === 'ar' ? product?.nameAr : product?.name}</p>
                        <p className="text-xs text-muted-foreground">{language === 'ar' ? store?.nameAr : store?.name}</p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {isHighRisk && <AlertTriangle className="h-4 w-4 text-destructive" />}
                        <div>
                          <p className="font-medium">{buyer?.name}</p>
                          <p className="text-xs text-muted-foreground">{buyer?.phone}</p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="text-center">{order.quantity}</TableCell>
                    <TableCell className="font-medium">${order.totalPrice.toFixed(2)}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className={cn('capitalize', statusColors[order.status])}>
                        {t(order.status as 'pending' | 'confirmed' | 'delivered' | 'returned' | 'problematic')}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {new Date(order.createdAt).toLocaleDateString()}
                    </TableCell>
                    {showActions && (
                      <TableCell className="text-end">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>{t('actions')}</DropdownMenuLabel>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem onClick={() => handleView(order)}>
                              <Eye className="h-4 w-4 me-2" />
                              View Details
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleEdit(order)}>
                              <Edit className="h-4 w-4 me-2" />
                              {t('edit')}
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem
                              onClick={() => handleDelete(order.id)}
                              className="text-destructive"
                            >
                              <Trash2 className="h-4 w-4 me-2" />
                              {t('delete')}
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    )}
                  </TableRow>
                )
              })
            )}
          </TableBody>
        </Table>
      </div>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{t('editOrder')}</DialogTitle>
            <DialogDescription>
              Update order status and notes
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>{t('status')}</Label>
              <Select value={editStatus} onValueChange={(v) => setEditStatus(v as OrderStatus)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pending">{t('pending')}</SelectItem>
                  <SelectItem value="confirmed">{t('confirmed')}</SelectItem>
                  <SelectItem value="delivered">{t('delivered')}</SelectItem>
                  <SelectItem value="returned">{t('returned')}</SelectItem>
                  <SelectItem value="problematic">{t('problematic')}</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>{t('notes')}</Label>
              <Textarea
                value={editNotes}
                onChange={(e) => setEditNotes(e.target.value)}
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              {t('cancel')}
            </Button>
            <Button onClick={handleSaveEdit}>{t('save')}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* View Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{t('orderDetails')}</DialogTitle>
          </DialogHeader>
          {selectedOrder && (
            <div className="space-y-4 py-4">
              {(() => {
                const product = products.find(p => p.id === selectedOrder.productId)
                const buyer = buyers.find(b => b.id === selectedOrder.buyerId)
                const store = stores.find(s => s.id === selectedOrder.storeId)
                return (
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="space-y-2">
                      <Label className="text-muted-foreground">Order ID</Label>
                      <p className="font-mono">{selectedOrder.id}</p>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-muted-foreground">{t('status')}</Label>
                      <Badge variant="outline" className={cn('capitalize', statusColors[selectedOrder.status])}>
                        {t(selectedOrder.status as 'pending' | 'confirmed' | 'delivered' | 'returned' | 'problematic')}
                      </Badge>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-muted-foreground">{t('stores')}</Label>
                      <p>{language === 'ar' ? store?.nameAr : store?.name}</p>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-muted-foreground">{t('products')}</Label>
                      <p>{language === 'ar' ? product?.nameAr : product?.name}</p>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-muted-foreground">Buyer</Label>
                      <div>
                        <p>{buyer?.name}</p>
                        <p className="text-sm text-muted-foreground">{buyer?.phone}</p>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-muted-foreground">{t('address')}</Label>
                      <p className="text-sm">{buyer?.governorate}, {buyer?.district}</p>
                      <p className="text-sm text-muted-foreground">{buyer?.landmark}</p>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-muted-foreground">{t('quantity')}</Label>
                      <p>{selectedOrder.quantity}</p>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-muted-foreground">{t('total')}</Label>
                      <p className="font-bold">${selectedOrder.totalPrice.toFixed(2)}</p>
                    </div>
                    {selectedOrder.notes && (
                      <div className="space-y-2 sm:col-span-2">
                        <Label className="text-muted-foreground">{t('notes')}</Label>
                        <p className="text-sm">{selectedOrder.notes}</p>
                      </div>
                    )}
                  </div>
                )
              })()}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
