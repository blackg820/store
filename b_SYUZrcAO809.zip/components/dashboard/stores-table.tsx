'use client'

import { useState } from 'react'
import { useData } from '@/lib/data-context'
import { useTranslations } from '@/hooks/use-translations'
import { useAuth } from '@/lib/auth-context'
import type { Store } from '@/lib/types'
import { cn } from '@/lib/utils'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import { MoreHorizontal, Search, Plus, Eye, Edit, Trash2, ExternalLink, Copy, Store as StoreIcon } from 'lucide-react'
import Link from 'next/link'

interface StoresTableProps {
  userId?: string
  showOwner?: boolean
}

export function StoresTable({ userId, showOwner = false }: StoresTableProps) {
  const { language, user } = useAuth()
  const { t } = useTranslations()
  const { stores, users, products, orders, addStore, updateStore, deleteStore, getProductsByStoreId, getOrdersByStoreId } = useData()
  
  const [searchQuery, setSearchQuery] = useState('')
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [selectedStore, setSelectedStore] = useState<Store | null>(null)
  
  // Form state
  const [formData, setFormData] = useState({
    name: '',
    nameAr: '',
    slug: '',
    description: '',
    descriptionAr: '',
    isActive: true,
    globalDiscount: 0,
  })

  let filteredStores = userId 
    ? stores.filter(s => s.userId === userId)
    : stores

  if (searchQuery) {
    filteredStores = filteredStores.filter(s => 
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.nameAr.includes(searchQuery) ||
      s.slug.includes(searchQuery.toLowerCase())
    )
  }

  const resetForm = () => {
    setFormData({
      name: '',
      nameAr: '',
      slug: '',
      description: '',
      descriptionAr: '',
      isActive: true,
      globalDiscount: 0,
    })
  }

  const handleAdd = () => {
    const targetUserId = userId || user?.id
    if (!targetUserId) return
    
    addStore({
      ...formData,
      userId: targetUserId,
      globalDiscount: formData.globalDiscount > 0 ? formData.globalDiscount : undefined,
    })
    setIsAddDialogOpen(false)
    resetForm()
  }

  const handleEdit = (store: Store) => {
    setSelectedStore(store)
    setFormData({
      name: store.name,
      nameAr: store.nameAr,
      slug: store.slug,
      description: store.description,
      descriptionAr: store.descriptionAr,
      isActive: store.isActive,
      globalDiscount: store.globalDiscount || 0,
    })
    setIsEditDialogOpen(true)
  }

  const handleSaveEdit = () => {
    if (selectedStore) {
      updateStore(selectedStore.id, {
        ...formData,
        globalDiscount: formData.globalDiscount > 0 ? formData.globalDiscount : undefined,
      })
      setIsEditDialogOpen(false)
      resetForm()
    }
  }

  const handleDelete = (storeId: string) => {
    if (confirm(t('areYouSure'))) {
      deleteStore(storeId)
    }
  }

  const copyStoreLink = (slug: string) => {
    const url = `${window.location.origin}/store/${slug}`
    navigator.clipboard.writeText(url)
  }

  const StoreFormFields = () => (
    <div className="grid gap-4 py-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="name">Name (English)</Label>
          <Input
            id="name"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="nameAr">Name (Arabic)</Label>
          <Input
            id="nameAr"
            value={formData.nameAr}
            onChange={(e) => setFormData({ ...formData, nameAr: e.target.value })}
            dir="rtl"
          />
        </div>
      </div>
      <div className="space-y-2">
        <Label htmlFor="slug">URL Slug</Label>
        <Input
          id="slug"
          value={formData.slug}
          onChange={(e) => setFormData({ ...formData, slug: e.target.value.toLowerCase().replace(/\s+/g, '-') })}
          placeholder="my-store"
        />
        <p className="text-xs text-muted-foreground">
          Store URL: {window.location.origin}/store/{formData.slug || 'my-store'}
        </p>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="description">Description (English)</Label>
          <Textarea
            id="description"
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            rows={2}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="descriptionAr">Description (Arabic)</Label>
          <Textarea
            id="descriptionAr"
            value={formData.descriptionAr}
            onChange={(e) => setFormData({ ...formData, descriptionAr: e.target.value })}
            rows={2}
            dir="rtl"
          />
        </div>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="discount">Global Discount (%)</Label>
          <Input
            id="discount"
            type="number"
            min="0"
            max="100"
            value={formData.globalDiscount}
            onChange={(e) => setFormData({ ...formData, globalDiscount: parseInt(e.target.value) || 0 })}
          />
        </div>
        <div className="flex items-center gap-2 pt-6">
          <Switch
            id="isActive"
            checked={formData.isActive}
            onCheckedChange={(checked) => setFormData({ ...formData, isActive: checked })}
          />
          <Label htmlFor="isActive">{t('active')}</Label>
        </div>
      </div>
    </div>
  )

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
        <div className="relative w-full sm:w-64">
          <Search className="absolute start-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder={t('search')}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="ps-9"
          />
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={resetForm}>
              <Plus className="h-4 w-4 me-2" />
              {t('add')} {t('stores')}
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>{t('add')} {t('stores')}</DialogTitle>
              <DialogDescription>
                Create a new store for your business
              </DialogDescription>
            </DialogHeader>
            <StoreFormFields />
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                {t('cancel')}
              </Button>
              <Button onClick={handleAdd}>{t('save')}</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="rounded-lg border border-border bg-card overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50">
              <TableHead>{t('storeName')}</TableHead>
              {showOwner && <TableHead>Owner</TableHead>}
              <TableHead>Slug</TableHead>
              <TableHead className="text-center">{t('products')}</TableHead>
              <TableHead className="text-center">{t('orders')}</TableHead>
              <TableHead>{t('discount')}</TableHead>
              <TableHead>{t('status')}</TableHead>
              <TableHead className="text-end">{t('actions')}</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredStores.length === 0 ? (
              <TableRow>
                <TableCell colSpan={showOwner ? 8 : 7} className="text-center py-8 text-muted-foreground">
                  {t('noData')}
                </TableCell>
              </TableRow>
            ) : (
              filteredStores.map((store) => {
                const owner = users.find(u => u.id === store.userId)
                const productCount = getProductsByStoreId(store.id).length
                const orderCount = getOrdersByStoreId(store.id).length

                return (
                  <TableRow key={store.id}>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                          <StoreIcon className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <p className="font-medium">{language === 'ar' ? store.nameAr : store.name}</p>
                          <p className="text-xs text-muted-foreground">
                            {new Date(store.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                    </TableCell>
                    {showOwner && (
                      <TableCell>
                        <p>{owner?.name}</p>
                        <p className="text-xs text-muted-foreground">{owner?.email}</p>
                      </TableCell>
                    )}
                    <TableCell>
                      <code className="text-xs bg-muted px-2 py-1 rounded">{store.slug}</code>
                    </TableCell>
                    <TableCell className="text-center">{productCount}</TableCell>
                    <TableCell className="text-center">{orderCount}</TableCell>
                    <TableCell>
                      {store.globalDiscount ? (
                        <Badge variant="secondary">{store.globalDiscount}% off</Badge>
                      ) : (
                        <span className="text-muted-foreground">-</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge variant={store.isActive ? 'default' : 'secondary'}>
                        {store.isActive ? t('active') : t('inactive')}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-end">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel>{t('actions')}</DropdownMenuLabel>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem asChild>
                            <Link href={`/store/${store.slug}`} target="_blank">
                              <ExternalLink className="h-4 w-4 me-2" />
                              View Store
                            </Link>
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => copyStoreLink(store.slug)}>
                            <Copy className="h-4 w-4 me-2" />
                            Copy Link
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleEdit(store)}>
                            <Edit className="h-4 w-4 me-2" />
                            {t('edit')}
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem
                            onClick={() => handleDelete(store.id)}
                            className="text-destructive"
                          >
                            <Trash2 className="h-4 w-4 me-2" />
                            {t('delete')}
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                )
              })
            )}
          </TableBody>
        </Table>
      </div>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{t('edit')} {t('stores')}</DialogTitle>
            <DialogDescription>
              Update store information
            </DialogDescription>
          </DialogHeader>
          <StoreFormFields />
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              {t('cancel')}
            </Button>
            <Button onClick={handleSaveEdit}>{t('save')}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
