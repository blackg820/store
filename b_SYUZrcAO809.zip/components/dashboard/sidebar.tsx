'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { cn } from '@/lib/utils'
import { useAuth } from '@/lib/auth-context'
import { useTranslations } from '@/hooks/use-translations'
import {
  LayoutDashboard,
  Store,
  Package,
  ShoppingCart,
  Users,
  CreditCard,
  Settings,
  LogOut,
  Globe,
  ChevronLeft,
  ChevronRight,
  UserCircle,
  Layers,
  FileText,
  BarChart3,
  Percent,
  Key,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useState } from 'react'

interface NavItem {
  href: string
  label: { en: string; ar: string }
  icon: React.ElementType
  adminOnly?: boolean
}

const navItems: NavItem[] = [
  { href: '/dashboard', label: { en: 'Dashboard', ar: 'لوحة التحكم' }, icon: LayoutDashboard },
  { href: '/dashboard/stores', label: { en: 'Stores', ar: 'المتاجر' }, icon: Store },
  { href: '/dashboard/products', label: { en: 'Products', ar: 'المنتجات' }, icon: Package },
  { href: '/dashboard/product-types', label: { en: 'Product Types', ar: 'أنواع المنتجات' }, icon: Layers },
  { href: '/dashboard/orders', label: { en: 'Orders', ar: 'الطلبات' }, icon: ShoppingCart },
  { href: '/dashboard/buyers', label: { en: 'Buyers', ar: 'المشترين' }, icon: Users },
  { href: '/dashboard/discounts', label: { en: 'Discounts', ar: 'الخصومات' }, icon: Percent },
  { href: '/dashboard/analytics', label: { en: 'Analytics', ar: 'التحليلات' }, icon: BarChart3 },
  { href: '/dashboard/api-keys', label: { en: 'API Keys', ar: 'مفاتيح API' }, icon: Key },
  { href: '/dashboard/users', label: { en: 'Users', ar: 'المستخدمين' }, icon: UserCircle, adminOnly: true },
  { href: '/dashboard/subscriptions', label: { en: 'Subscriptions', ar: 'الاشتراكات' }, icon: CreditCard, adminOnly: true },
  { href: '/dashboard/audit-logs', label: { en: 'Audit Logs', ar: 'سجلات التدقيق' }, icon: FileText, adminOnly: true },
  { href: '/dashboard/settings', label: { en: 'Settings', ar: 'الإعدادات' }, icon: Settings },
]

export function DashboardSidebar() {
  const pathname = usePathname()
  const { user, logout, language, setLanguage } = useAuth()
  const { t } = useTranslations()
  const [collapsed, setCollapsed] = useState(false)

  const filteredNavItems = navItems.filter(item => {
    if (item.adminOnly && user?.role !== 'admin') return false
    return true
  })

  const toggleLanguage = () => {
    setLanguage(language === 'en' ? 'ar' : 'en')
  }

  return (
    <aside
      className={cn(
        'fixed top-0 h-screen bg-sidebar text-sidebar-foreground border-e border-sidebar-border flex flex-col transition-all duration-300 z-50',
        collapsed ? 'w-16' : 'w-64',
        language === 'ar' ? 'right-0' : 'left-0'
      )}
    >
      <div className="flex items-center justify-between p-4 border-b border-sidebar-border">
        {!collapsed && (
          <Link href="/dashboard" className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-lg bg-sidebar-primary flex items-center justify-center">
              <Store className="h-5 w-5 text-sidebar-primary-foreground" />
            </div>
            <span className="font-semibold text-lg">Storify</span>
          </Link>
        )}
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setCollapsed(!collapsed)}
          className="text-sidebar-foreground hover:bg-sidebar-accent shrink-0"
        >
          {collapsed ? (
            language === 'ar' ? <ChevronLeft className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />
          ) : (
            language === 'ar' ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />
          )}
        </Button>
      </div>

      <nav className="flex-1 py-4 overflow-y-auto">
        <ul className="space-y-1 px-2">
          {filteredNavItems.map((item) => {
            const isActive = pathname === item.href || pathname.startsWith(item.href + '/')
            return (
              <li key={item.href}>
                <Link
                  href={item.href}
                  className={cn(
                    'flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors',
                    isActive
                      ? 'bg-sidebar-primary text-sidebar-primary-foreground'
                      : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
                  )}
                >
                  <item.icon className="h-5 w-5 shrink-0" />
                  {!collapsed && <span className="truncate">{language === 'ar' ? item.label.ar : item.label.en}</span>}
                </Link>
              </li>
            )
          })}
        </ul>
      </nav>

      <div className="p-4 border-t border-sidebar-border space-y-2">
        <Button
          variant="ghost"
          size={collapsed ? 'icon' : 'default'}
          onClick={toggleLanguage}
          className={cn(
            'text-sidebar-foreground hover:bg-sidebar-accent',
            collapsed ? 'w-full justify-center' : 'w-full justify-start'
          )}
        >
          <Globe className="h-5 w-5 shrink-0" />
          {!collapsed && (
            <span className="ms-3">{language === 'en' ? 'العربية' : 'English'}</span>
          )}
        </Button>
        
        <Button
          variant="ghost"
          size={collapsed ? 'icon' : 'default'}
          onClick={logout}
          className={cn(
            'text-sidebar-foreground hover:bg-sidebar-accent hover:text-destructive',
            collapsed ? 'w-full justify-center' : 'w-full justify-start'
          )}
        >
          <LogOut className="h-5 w-5 shrink-0" />
          {!collapsed && <span className="ms-3">{t('logout')}</span>}
        </Button>
      </div>
    </aside>
  )
}
