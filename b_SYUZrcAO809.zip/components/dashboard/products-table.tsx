'use client'

import { useState } from 'react'
import { useData } from '@/lib/data-context'
import { useTranslations } from '@/hooks/use-translations'
import { useAuth } from '@/lib/auth-context'
import type { Product } from '@/lib/types'
import { cn } from '@/lib/utils'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import { MoreHorizontal, Search, Plus, Edit, Trash2, ExternalLink, Star, Package, Image } from 'lucide-react'
import Link from 'next/link'

interface ProductsTableProps {
  storeId?: string
  userId?: string
}

export function ProductsTable({ storeId, userId }: ProductsTableProps) {
  const { language, user } = useAuth()
  const { t } = useTranslations()
  const { products, stores, getStoresByUserId, addProduct, updateProduct, deleteProduct } = useData()
  
  const [searchQuery, setSearchQuery] = useState('')
  const [storeFilter, setStoreFilter] = useState<string>(storeId || 'all')
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)
  
  // Get user's stores for filtering
  const userStores = userId 
    ? getStoresByUserId(userId)
    : user?.role === 'admin' 
      ? stores 
      : getStoresByUserId(user?.id || '')
  
  // Form state
  const [formData, setFormData] = useState({
    storeId: storeId || '',
    name: '',
    nameAr: '',
    description: '',
    descriptionAr: '',
    price: 0,
    discount: 0,
    isActive: true,
    images: [''],
    videos: [''],
  })

  // Filter products
  let filteredProducts = products

  if (storeId) {
    filteredProducts = filteredProducts.filter(p => p.storeId === storeId)
  } else if (userId) {
    const userStoreIds = userStores.map(s => s.id)
    filteredProducts = filteredProducts.filter(p => userStoreIds.includes(p.storeId))
  } else if (user?.role !== 'admin') {
    const userStoreIds = getStoresByUserId(user?.id || '').map(s => s.id)
    filteredProducts = filteredProducts.filter(p => userStoreIds.includes(p.storeId))
  }

  if (storeFilter && storeFilter !== 'all') {
    filteredProducts = filteredProducts.filter(p => p.storeId === storeFilter)
  }

  if (searchQuery) {
    filteredProducts = filteredProducts.filter(p => 
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.nameAr.includes(searchQuery)
    )
  }

  const resetForm = () => {
    setFormData({
      storeId: storeId || '',
      name: '',
      nameAr: '',
      description: '',
      descriptionAr: '',
      price: 0,
      discount: 0,
      isActive: true,
      images: [''],
      videos: [''],
    })
  }

  const handleAdd = () => {
    if (!formData.storeId) return
    
    addProduct({
      storeId: formData.storeId,
      name: formData.name,
      nameAr: formData.nameAr,
      description: formData.description,
      descriptionAr: formData.descriptionAr,
      price: formData.price,
      discount: formData.discount > 0 ? formData.discount : undefined,
      isActive: formData.isActive,
      images: formData.images.filter(Boolean),
      videos: formData.videos.filter(Boolean),
    })
    setIsAddDialogOpen(false)
    resetForm()
  }

  const handleEdit = (product: Product) => {
    setSelectedProduct(product)
    setFormData({
      storeId: product.storeId,
      name: product.name,
      nameAr: product.nameAr,
      description: product.description,
      descriptionAr: product.descriptionAr,
      price: product.price,
      discount: product.discount || 0,
      isActive: product.isActive,
      images: product.images.length > 0 ? product.images : [''],
      videos: product.videos.length > 0 ? product.videos : [''],
    })
    setIsEditDialogOpen(true)
  }

  const handleSaveEdit = () => {
    if (selectedProduct) {
      updateProduct(selectedProduct.id, {
        name: formData.name,
        nameAr: formData.nameAr,
        description: formData.description,
        descriptionAr: formData.descriptionAr,
        price: formData.price,
        discount: formData.discount > 0 ? formData.discount : undefined,
        isActive: formData.isActive,
        images: formData.images.filter(Boolean),
        videos: formData.videos.filter(Boolean),
      })
      setIsEditDialogOpen(false)
      resetForm()
    }
  }

  const handleDelete = (productId: string) => {
    if (confirm(t('areYouSure'))) {
      deleteProduct(productId)
    }
  }

  const ProductFormFields = () => (
    <div className="grid gap-4 py-4 max-h-[60vh] overflow-y-auto">
      {!storeId && (
        <div className="space-y-2">
          <Label>{t('stores')}</Label>
          <Select 
            value={formData.storeId} 
            onValueChange={(v) => setFormData({ ...formData, storeId: v })}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select a store" />
            </SelectTrigger>
            <SelectContent>
              {userStores.map(store => (
                <SelectItem key={store.id} value={store.id}>
                  {language === 'ar' ? store.nameAr : store.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="name">Name (English)</Label>
          <Input
            id="name"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="nameAr">Name (Arabic)</Label>
          <Input
            id="nameAr"
            value={formData.nameAr}
            onChange={(e) => setFormData({ ...formData, nameAr: e.target.value })}
            dir="rtl"
          />
        </div>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="description">Description (English)</Label>
          <Textarea
            id="description"
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            rows={2}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="descriptionAr">Description (Arabic)</Label>
          <Textarea
            id="descriptionAr"
            value={formData.descriptionAr}
            onChange={(e) => setFormData({ ...formData, descriptionAr: e.target.value })}
            rows={2}
            dir="rtl"
          />
        </div>
      </div>
      <div className="grid grid-cols-3 gap-4">
        <div className="space-y-2">
          <Label htmlFor="price">{t('price')} ($)</Label>
          <Input
            id="price"
            type="number"
            min="0"
            step="0.01"
            value={formData.price}
            onChange={(e) => setFormData({ ...formData, price: parseFloat(e.target.value) || 0 })}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="discount">{t('discount')} (%)</Label>
          <Input
            id="discount"
            type="number"
            min="0"
            max="100"
            value={formData.discount}
            onChange={(e) => setFormData({ ...formData, discount: parseInt(e.target.value) || 0 })}
          />
        </div>
        <div className="flex items-center gap-2 pt-6">
          <Switch
            id="isActive"
            checked={formData.isActive}
            onCheckedChange={(checked) => setFormData({ ...formData, isActive: checked })}
          />
          <Label htmlFor="isActive">{t('active')}</Label>
        </div>
      </div>
      <div className="space-y-2">
        <Label>Image URLs</Label>
        {formData.images.map((img, index) => (
          <div key={index} className="flex gap-2">
            <Input
              value={img}
              onChange={(e) => {
                const newImages = [...formData.images]
                newImages[index] = e.target.value
                setFormData({ ...formData, images: newImages })
              }}
              placeholder="https://..."
            />
            {index === formData.images.length - 1 && (
              <Button
                type="button"
                variant="outline"
                size="icon"
                onClick={() => setFormData({ ...formData, images: [...formData.images, ''] })}
              >
                <Plus className="h-4 w-4" />
              </Button>
            )}
          </div>
        ))}
      </div>
    </div>
  )

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
        <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
          <div className="relative">
            <Search className="absolute start-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder={t('search')}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="ps-9 w-full sm:w-64"
            />
          </div>
          {!storeId && userStores.length > 1 && (
            <Select value={storeFilter} onValueChange={setStoreFilter}>
              <SelectTrigger className="w-full sm:w-48">
                <SelectValue placeholder={t('filter')} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Stores</SelectItem>
                {userStores.map(store => (
                  <SelectItem key={store.id} value={store.id}>
                    {language === 'ar' ? store.nameAr : store.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={resetForm}>
              <Plus className="h-4 w-4 me-2" />
              {t('add')} Product
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>{t('add')} Product</DialogTitle>
              <DialogDescription>
                Add a new product to your store
              </DialogDescription>
            </DialogHeader>
            <ProductFormFields />
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                {t('cancel')}
              </Button>
              <Button onClick={handleAdd} disabled={!formData.storeId || !formData.name}>
                {t('save')}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="rounded-lg border border-border bg-card overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50">
              <TableHead>{t('products')}</TableHead>
              <TableHead>{t('stores')}</TableHead>
              <TableHead>{t('price')}</TableHead>
              <TableHead>{t('discount')}</TableHead>
              <TableHead>{t('rating')}</TableHead>
              <TableHead>{t('status')}</TableHead>
              <TableHead className="text-end">{t('actions')}</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredProducts.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                  {t('noData')}
                </TableCell>
              </TableRow>
            ) : (
              filteredProducts.map((product) => {
                const store = stores.find(s => s.id === product.storeId)
                const finalPrice = product.discount 
                  ? product.price * (1 - product.discount / 100)
                  : product.price

                return (
                  <TableRow key={product.id}>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <div className="h-12 w-12 rounded-lg bg-muted flex items-center justify-center overflow-hidden">
                          {product.images[0] ? (
                            <img 
                              src={product.images[0]} 
                              alt={product.name}
                              className="h-full w-full object-cover"
                            />
                          ) : (
                            <Package className="h-6 w-6 text-muted-foreground" />
                          )}
                        </div>
                        <div>
                          <p className="font-medium">{language === 'ar' ? product.nameAr : product.name}</p>
                          <p className="text-xs text-muted-foreground line-clamp-1">
                            {language === 'ar' ? product.descriptionAr : product.description}
                          </p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <span className="text-sm">{language === 'ar' ? store?.nameAr : store?.name}</span>
                    </TableCell>
                    <TableCell>
                      <div>
                        <p className="font-medium">${finalPrice.toFixed(2)}</p>
                        {product.discount && (
                          <p className="text-xs text-muted-foreground line-through">
                            ${product.price.toFixed(2)}
                          </p>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      {product.discount ? (
                        <Badge variant="secondary" className="bg-success/10 text-success border-success/20">
                          {product.discount}% off
                        </Badge>
                      ) : (
                        <span className="text-muted-foreground">-</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Star className="h-4 w-4 fill-warning text-warning" />
                        <span className="font-medium">{product.averageRating.toFixed(1)}</span>
                        <span className="text-xs text-muted-foreground">({product.totalRatings})</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant={product.isActive ? 'default' : 'secondary'}>
                        {product.isActive ? t('active') : t('inactive')}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-end">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel>{t('actions')}</DropdownMenuLabel>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem asChild>
                            <Link href={`/store/${store?.slug}/product/${product.id}`} target="_blank">
                              <ExternalLink className="h-4 w-4 me-2" />
                              View Product
                            </Link>
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleEdit(product)}>
                            <Edit className="h-4 w-4 me-2" />
                            {t('edit')}
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem
                            onClick={() => handleDelete(product.id)}
                            className="text-destructive"
                          >
                            <Trash2 className="h-4 w-4 me-2" />
                            {t('delete')}
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                )
              })
            )}
          </TableBody>
        </Table>
      </div>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{t('edit')} Product</DialogTitle>
            <DialogDescription>
              Update product information
            </DialogDescription>
          </DialogHeader>
          <ProductFormFields />
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              {t('cancel')}
            </Button>
            <Button onClick={handleSaveEdit}>{t('save')}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
