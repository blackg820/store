'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { useAuth } from '@/lib/auth-context'
import { useData } from '@/lib/data-context'
import { useTranslations } from '@/hooks/use-translations'
import { ShoppingCart, Store, DollarSign, Users, TrendingUp, TrendingDown, Package, AlertTriangle } from 'lucide-react'
import { cn } from '@/lib/utils'

interface StatCardProps {
  title: string
  value: string | number
  icon: React.ElementType
  trend?: {
    value: number
    isPositive: boolean
  }
  variant?: 'default' | 'success' | 'warning' | 'danger'
}

function StatCard({ title, value, icon: Icon, trend, variant = 'default' }: StatCardProps) {
  const variantStyles = {
    default: 'bg-primary/10 text-primary',
    success: 'bg-success/10 text-success',
    warning: 'bg-warning/10 text-warning',
    danger: 'bg-destructive/10 text-destructive',
  }

  return (
    <Card className="relative overflow-hidden">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">{title}</CardTitle>
        <div className={cn('p-2 rounded-lg', variantStyles[variant])}>
          <Icon className="h-4 w-4" />
        </div>
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        {trend && (
          <p className={cn(
            'text-xs flex items-center gap-1 mt-1',
            trend.isPositive ? 'text-success' : 'text-destructive'
          )}>
            {trend.isPositive ? (
              <TrendingUp className="h-3 w-3" />
            ) : (
              <TrendingDown className="h-3 w-3" />
            )}
            {trend.value}% from last month
          </p>
        )}
      </CardContent>
    </Card>
  )
}

export function AdminStatsCards() {
  const { t } = useTranslations()
  const { orders, stores, buyers } = useData()
  
  const totalRevenue = orders
    .filter(o => o.status === 'delivered')
    .reduce((sum, o) => sum + o.totalPrice, 0)
  
  const pendingOrders = orders.filter(o => o.status === 'pending').length
  const activeStores = stores.filter(s => s.isActive).length
  const highRiskBuyers = buyers.filter(b => b.riskScore === 'high').length

  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      <StatCard
        title={t('totalOrders')}
        value={orders.length}
        icon={ShoppingCart}
        trend={{ value: 12, isPositive: true }}
      />
      <StatCard
        title={t('totalRevenue')}
        value={`$${totalRevenue.toFixed(2)}`}
        icon={DollarSign}
        trend={{ value: 8, isPositive: true }}
        variant="success"
      />
      <StatCard
        title={t('totalStores')}
        value={`${activeStores} / ${stores.length}`}
        icon={Store}
      />
      <StatCard
        title="High Risk Buyers"
        value={highRiskBuyers}
        icon={AlertTriangle}
        variant={highRiskBuyers > 0 ? 'warning' : 'default'}
      />
    </div>
  )
}

export function StoreOwnerStatsCards({ userId }: { userId: string }) {
  const { t } = useTranslations()
  const { getStoresByUserId, orders, products } = useData()
  
  const userStores = getStoresByUserId(userId)
  const storeIds = userStores.map(s => s.id)
  
  const userOrders = orders.filter(o => storeIds.includes(o.storeId))
  const userProducts = products.filter(p => storeIds.includes(p.storeId))
  
  const totalRevenue = userOrders
    .filter(o => o.status === 'delivered')
    .reduce((sum, o) => sum + o.totalPrice, 0)
  
  const pendingOrders = userOrders.filter(o => o.status === 'pending').length

  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      <StatCard
        title={t('totalOrders')}
        value={userOrders.length}
        icon={ShoppingCart}
        trend={{ value: 5, isPositive: true }}
      />
      <StatCard
        title={t('totalRevenue')}
        value={`$${totalRevenue.toFixed(2)}`}
        icon={DollarSign}
        trend={{ value: 12, isPositive: true }}
        variant="success"
      />
      <StatCard
        title={t('stores')}
        value={userStores.length}
        icon={Store}
      />
      <StatCard
        title={t('products')}
        value={userProducts.length}
        icon={Package}
      />
    </div>
  )
}
